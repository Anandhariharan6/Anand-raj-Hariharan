package StringTest;

import java.util.Scanner;

public class ReplacingStringsWith {
	public static String replace(String s)
	{
		String str= " ";
		for (int i = 0; i < s.length(); i++) 
		{
			if(s.charAt(i)==' ')
			{
				str = str+'@';
			}
			else
			{
				str = str + s.charAt(i);
			}
		}
		return str;
		
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter a string");
		String s= in.nextLine();
		String res=replace(s);
		System.out.println(res);

	}

}
