package StringTest;

import java.util.Scanner;

public class ReplacingEvenCharacterOfStringWithNextCharacter {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter a String");
		String s= in.nextLine();
		char c=0;
		String s1=" ";
		for (int i = 0; i < s.length(); i++) 
		{
			if(i%2 != 0 && s.charAt(i)!=' ')
			{
				c= (char)(s.charAt(i)+1);
				s1=s1+c;
			}
			else
			{
				s1=s1+s.charAt(i);
			}
		}
		System.out.println(s1);
				
	}

}
