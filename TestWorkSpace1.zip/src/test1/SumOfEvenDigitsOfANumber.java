package test1;

import java.util.Scanner;

public class SumOfEvenDigitsOfANumber 
{
	public static int evenDigitSum(int n)
	{
		int sum=0,count=0,r = 0;
		while(n!=0)
		{
			r=r%10;
			n=n/10;
			count++;
		}
		if(count%2==0)
		{
			sum=sum+r;
		}
		return sum;
	}


	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter a number");
		int number=in.nextInt();
		if(number>0) 
		{
			(int) int value = evenDigitSum(number);
			System.out.println(value);
		}
		else
			System.out.println("invalid");
	}
}
