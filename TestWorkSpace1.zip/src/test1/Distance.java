package test1;

import java.util.Scanner;

public class Distance {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int sum=0;
		System.out.println("enter the distance");
		int x= in .nextInt();
		System.out.println("ente no. of days");
		int y =in.nextInt();
		System.out.println("first day");
		int fd = in.nextInt();
		System.out.println("second day");
		int sd = in.nextInt();
		System.out.println("third day");
		int td = in.nextInt();
		sum=fd+sd+td;
		if(x>sum)
		{
			System.out.println("invalid combination");
		}
		else if(x<sum)
		{
			System.out.println("traveller covering more km");
		}
		else
		{
			System.out.println("perfect combination");
		}
	}
}
