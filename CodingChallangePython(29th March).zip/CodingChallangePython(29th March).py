# -*- coding: utf-8 -*-
"""
Created on Sun Mar 29 18:09:23 2020

@author: M1057669
"""

'''
1.Write a program that takes your full name as input
 and displays the abbreviations of the first and middle 
 names except the last name which is displayed as it is. 
 For example, if your name is Robert Brett Roser,
 then the output should be R.B.Roser.
'''
def fullName(n):
    list1=n.split()
    space=""
    for i in range(len(list1)-1):
        n=list1[i]
        space = space +(n[0].upper() +'.')
        
    space =space+list1[-1].title()
    return space
n=input("Enter Your Name:")
print("Abbreviated name is:",fullName(n))

#====================================================================
'''
2.  write a python program to which takes an input 
string and creates a dictionary as below

word_list = 'aaaaabbbbcccdde' 
word_freq = { ’a’ : 5, ’b’ : 4, ’c’ : 3, ’d’ : 2, ’e’ : 1 }
'''
def f(s):
    freq={}
    for i in s:
        if i in freq:
            freq[i]=freq[i]+1
        else:
            freq[i]=1
    return freq
s=input("Enter a string:")
print(f(s))
#=====================================================================
'''
3.Create a list of tuples which contain Name age
 and score and sort the list by score highest to lowest
'''
num=int(input("Enter the number of elements you want: "))
list1=[]
for i in range (num):
    name=input()
    age=int(input())
    score=int(input())
    a=(name,age,score)
    list1.append(a)
print(list1)

for i in range(0,len(list1)-1,1):
    for j in range(i+1,len(list1),1):
        if list1[i][2]<list1[j][2]:
             temp=list1[i]
             list1[i]=list1[j]
             list1[j]=temp
print(list1)



#===================================================================

'''
4.
 "22 56 78 92 78" create a list which gives the 
 output as [4 30 56 18 56]
'''
def mult(s):
    sum=1
    list1=s.split(" ")
    list2=[]
    for i in range(0,len(list1)):
        list3=list(list1[i])
        for j in range(0,len(list3)):
            sum=sum*int(list3[j])   
        list2.append(sum)
        sum=1
    return list2
s=input("Enter the String:")
print(mult(s))
#===================================================================
'''
5. Read data from two different files union all the data and put all the 
data in a 3rd file named final file.
'''
f=open('C:/Users/M1057669/.spyder-py3/MyData.txt','r')
f=open('C:/Users/M1057669/.spyder-py3/MyData2.txt','r')


