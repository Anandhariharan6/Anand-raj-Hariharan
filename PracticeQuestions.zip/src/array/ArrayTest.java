package array;

import java.util.Scanner;

public class ArrayTest {
	public static void main(String[] args) {	
//		int x[];
//		x=new int[5];
//		int[] x= {1,2,3,4,5};    // if we know what are the members of the array
		
//		int x[]= new int[5];
//		for (int i = 0; i < x.length; i++) 
//		{
//			System.out.println("enter the elements of"+(i+1)" th position");
//			x[i]=in.nextInt();
//		}
//		for (int i = 0; i < x.length; i++) 
//		{
//			System.out.println(x[i]);   //printing the elements of the array
//		}
		Scanner in = new Scanner(System.in);
		System.out.println("enter the size of the array");
		int n=in.nextInt();	
		int x[]= new int[n];
		System.out.println("enter the elements of the array");
		for (int i = 0; i < x.length; i++) 
		{
			x[i]=in.nextInt();
		}
		for (int i = 0; i < x.length; i++) 
		{
			System.out.println();
		}
	}

}
