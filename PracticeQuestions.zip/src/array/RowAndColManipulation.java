package array;

import java.util.Scanner;

public class RowAndColManipulation 
{
	static Scanner in = new Scanner(System.in);
	
	public static void main(String[] args) 
	{
		System.out.println("enter no of rows");
		int row= in.nextInt();
		System.out.println("enter no of col");
		int col = in.nextInt();
		int a[][]= new int[row][col];
		System.out.println("enter for array a:");
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++)
			{
				a[i][j]=in.nextInt();
			}
		}
		int rd[]= new int[row];
		int ld[]=new int[row];
		int rowsum[]= new int[row];
		int colsum[]= new int[col];
		boolean flag=true;
		while(flag)
		{
			System.out.println("1: get the right diagonals");
			System.out.println("2: get the left diagonals");
			System.out.println("3: get row sum");
			System.out.println("4: get col sum");
			System.out.println("5: Swap right diagonal with left diagonal and dispalay");
			int choice=in.nextInt();
			switch(choice)
			{
			case 1:rightdiagonal(a,rd,row);
			break;
			case 2:leftdiagonal(a,ld,row);
			break;
			case 3:rowsum(a,rowsum);
			break;
			case 4:colsum(a,colsum);
			break;
			case 5:swapping(a,ld,rd,row);
			break;
			default:
				flag=false;
				System.out.println("invalid input");
			}
		}

	}

	public static void rightdiagonal(int a[][], int[] rd,int row) 
	{
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++)
			{
				if(i==j)
				{
					rd[i]=a[i][j];
				}
			}
		}
		for (int i = 0; i < a.length; i++)
		{
			System.out.print(rd[i]);
		}
		System.out.println();
		
	}
	
	public static void leftdiagonal(int a[][], int[] ld,int row)
	{
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++)
			{
				if(i+j==row-1)
				{
					ld[i]=a[i][j];
				}
			}
		}
		for (int i = 0; i < a.length; i++)
		{
			System.out.print(ld[i]);
		}
		System.out.println();
	}
	
	public static void rowsum(int a[][],int rowsum[])
	{
		int index=0;
		for (int i = 0; i < a.length; i++) 
		{
			int add=0;
			for (int j = 0; j < a.length; j++) 
			{
				add=add+a[i][j];
			}
			rowsum[index++]=add;
		}
		for (int i = 0; i < a.length; i++) 
		{
			System.out.println(rowsum[i]);
		}
	}
	
	public static void colsum(int a[][],int colsum[])
	{
		int index=0;
		for (int i = 0; i < a.length; i++) 
		{
			int add=0;
			for (int j = 0; j < a.length; j++) 
			{
				add=add+a[j][i];
			}
			colsum[index++]=add;
		}
		for (int i = 0; i < a.length; i++) 
		{
			System.out.println(colsum[i]);
		}
		
	}
	public static void swapping(int a[][],int ld[], int[] rd, int row)
	{
		for (int i = 0; i < a.length; i++)
		{
			for (int j = 0; j < a.length; j++) 
			{
				if(i==j)
				{
					int temp =a[i][j];
					a[i][j]=ld[i];
					ld[i]=temp;
				}
			}
		}
		for (int i = 0; i < a.length; i++)
		{
			for (int j = 0; j < a.length; j++) 
			{
				if(i+j==row-1)
				{
					int temp =a[i][j];
					a[i][j]=rd[i];
					rd[i]=temp;
				}
			}
		}
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++) 
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		
//		for (int i = 0; i < a.length; i++)
//		{
//			for (int j = 0; j < a.length; j++) 
//			{
//				if(i+j==row-1)
//				{
//					int temp =a[i][j];
//					a[i][j]=ld[i];
//					ld[i]=temp;
//				}
//			}
//		}
//		for (int i = 0; i < a.length; i++) 
//		{
//			for (int j = 0; j < a.length; j++) 
//			{
//				System.out.print(a[i][j]+" ");
//			}
//			System.out.println();
//		}
	}
	

}
	
