package array;

import java.util.Scanner;

public class ArrayElementsatEvenLoacation {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the no of elements you want in an array");
		int n = in.nextInt();
		int[] ar1 = new int[n];
		System.out.println("Enter elements of array");
		for (int i = 0; i < n; i++) 
		{
			ar1[i] = in.nextInt();
		}
		for (int j = 0; j < ar1.length; j++) 
		{
			if (ar1[j] % 2 == 0 && j%2==0)
			{
				ar1[j]=ar1[j]*2;
					System.out.println("at even place and is divisible by 2:" + j);
			}
		}
		for (int i = 0; i < ar1.length; i++) 
		{
			System.out.println(ar1[i]+"");
		}
			

		}

	}


