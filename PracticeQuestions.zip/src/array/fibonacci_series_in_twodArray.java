package array;

import java.util.Scanner;

public class fibonacci_series_in_twodArray 
{
	static Scanner in = new Scanner(System.in);
	static int[] fibonacci;
			public static int[] fib(int n,int n1,int n2)
			{
				int arr[]=new int[n*n];
				arr[0]=n1;
				arr[1]=n2;
				System.out.print(n1+" "+n2);
				for(int i=2;i< arr.length;i++)
				{
					int n3=n1+n2;
					arr[i]=n3;
					System.out.print(" "+n3);
					n1=n2;
					n2=n3;
				}
				for (int i = 0; i < arr.length; i++) {
					System.out.println(arr[i]);
				}
				return arr;
			}
			public static int[][] conversion(int arr[],int n) 
			{
				int r2[][]= new int[n][n];
				int index=0;
				for (int i = 0; i < n; i++) 
				{
					for (int j = 0; j < n; j++) 
					{
						r2[i][j]=arr[index++];
					}
				}

				for (int i = 0; i < n; i++) 
				{
					for (int j = 0; j < n; j++) 
					{
						System.out.println(r2[i][j]);
					}
					System.out.println();
				}
				return r2;	
			}
			
			public static void main(String[] args) 
			{
				System.out.println("enter the size of 1 d array");
				int n = in.nextInt();
				System.out.println("enter the first element:");
				int n1=in.nextInt();
				System.out.println("enter the second element:");
				int n2 = in.nextInt();
				fibonacci=fib(n,n1,n2);
				conversion(fibonacci,n);
			}
		
	}
