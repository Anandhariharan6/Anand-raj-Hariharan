package array;

import java.util.Scanner;

public class AllInOneArray {
	static int converted[];
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter the number of rows and coloum you want in the array: ");
		int n = in.nextInt();
		int a[][] = new int[n][n];
		System.out.println("enter the array elements for a:");
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				a[i][j] = in.nextInt();
			}
		}
		boolean flag = true;
		do {
			System.out.println("--menu--");
			System.out.println("1-left diagonal elements in 1 d array:");
			System.out.println("2-right diagonal elements in 1 d array:");
			System.out.println("3-swapping coloum:");
			System.out.println("4-swapping rows:");
			System.out.println("5-row sum:");
			System.out.println("6-col sum");
			System.out.println("7-printing the corner elements:");
			System.out.println("8-printing the middle element:");
			System.out.println("9-diagonal swapping:");
			System.out.println("10-converting to 1 d array:");
			System.out.println("11-converting back to 2 d array");
			System.out.println("12-printing all the element except the middle element");
			System.out.println("enter you choice");
			int c = in.nextInt();
			switch (c) {
			case 1: {
				int left[] = leftDiagonal(a);
				for (int i = 0; i < left.length; i++) {
					System.out.print(left[i] + " ");
				}
				System.out.println();
				break;
			}
			case 2: {
				int right[] = RightDiagonal(a);
				for (int i = 0; i < right.length; i++) {
					System.out.print(right[i] + " ");
				}
				System.out.println();
				break;
			}
			case 3: {
				int[][] swapcol = SwappingCol(a);
				for (int i = 0; i < swapcol.length; i++) 
				{
					for (int j = 0; j < swapcol.length; j++) 
					{
						System.out.print(swapcol[i][j]+" ");
					}
					System.out.println();
				}
				
				break;
			}
			case 4: {
				int[][] swaprow = SwappingRow(a);
				for (int i = 0; i < swaprow.length; i++) 
				{
					for (int j = 0; j < swaprow.length; j++) 
					{
						System.out.print(swaprow[i][j]+" ");
					}
					System.out.println();
				}
				break;
			}
			case 5: {
				int[] rowsum = RowSum(a);
				for (int i = 0; i < rowsum.length; i++)
				{
					System.out.print(rowsum[i]+" ");
				}
				System.out.println();
				break;
			}
			case 6: {
				int[] colsum = ColSum(a);
				for (int i = 0; i < colsum.length; i++) 
				{
					System.out.print(colsum[i]+" ");
				}
				System.out.println();
				break;
			}
			case 7: {
				int corner[] = CornerElements(a);
				break;
				
			}
			case 8: {
				int middel = middelElements(a);
					System.out.print(middel);
				break;
			}
			case 9: {
				int[][] dswap = SwappingDiagonal(a);
				for (int i = 0; i < dswap.length; i++) 
				{
					for (int j = 0; j < dswap[i].length; j++)
					{
						System.out.print(a[i][j]+" ");
					}
					System.out.println();
				}
				
				break;
			}
			case 10: {
				converted=Converted(a);
				for (int i = 0; i < converted.length; i++) 
				{
					System.out.print(converted[i]+" ");
				}
				System.out.println();
				break;
			}
			case 11:{
				int twod[][]=Twod(converted,n);
				for (int i = 0; i < twod.length; i++) 
				{
					for (int j = 0; j < twod[i].length; j++)
					{
						System.out.print(twod[i][j]+" ");
					}
					System.out.println();
				}
				break;
			}
			case 12:{
				int[] b_elements=boundary(a);
				for (int i = 0; i < b_elements.length; i++) 
				{
					System.out.print(b_elements[i]+" ");
				}
				System.out.println();
			}
			break;
			default:
				System.out.println("enter a valid choice:");
				break;
			}
		} while (flag);

	}

	private static int[] boundary(int[][] a)
	{
		int b[] =new int[a.length*a.length-1];
		int index=0;
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a[i].length; j++) 
			{
				if(i==0 || j==a.length-1 || j==0 || i== a.length-1)
				{
					b[index++]=a[i][j];
				}
			}
		}
		return b;
	}

	private static int[][] Twod(int[] converted2,int n)
	{ int index=0;
		int twoD[][]=new int[n][n];
		for (int i = 0; i < twoD.length; i++)
		{
			for (int j = 0; j < twoD.length; j++) 
			{
				twoD[i][j]=converted2[index++];
			}
		}
		return twoD;
	}

	private static int[] Converted(int[][] a)
	{
		int k =0;
		int index=0;
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a[i].length; j++) 
			{
				k++;
			}
		}
		int con[]=new int[k+1];
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++) 
			{
				con[index++]=a[i][j];
			}
		}
		return con;
	}

	private static int[][] SwappingDiagonal(int[][] a) 
	{
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a[i].length; j++)
			{
				if(i==j )
				{
					
					int t = a[i][j];
					a[i][j] = a[a.length -i- 1][j];
					a[a.length -i- 1][j] = t;
				}
			}
		}
		return a;
	}

	private static int middelElements(int[][] a) 
	{
		int middle=0;
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a[i].length; j++) 
			{
				if(i==1 && j==1)
				{
				middle=a[i][j];
				}
			}
		}
		return middle;
	}

	private static int[] CornerElements(int[][] a)
	{
		int corner[]=new int[4];
//		corner[0]=a[0][0];
//		corner[1]=a[0][a.length-1];
//		corner[2]=a[a.length-1][0];
//		corner[3]=a[a.length-1][a.length-1];
		int c=0;
		for (int i = 0; i < a.length; i++)
		{
			for (int j = 0; j < a[i].length; j++) 
			{
				if(i==0 && j==0 || i==0 && j==a.length-1 || i==a.length-1 && j==0 || j==a.length-1 && i==a.length-1 )
				{
					corner[c++]=a[i][j];
				}
			}
		}
		for (int i = 0; i < 4; i++) 
		{
			System.out.print(corner[i]+" ");
		}
		return corner;
	}

	private static int[] RightDiagonal(int[][] a) {
		int rd[] = new int[a.length];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (i == j) {
					rd[i] = a[i][j];
				}
			}
		}
		return rd;
	}

	private static int[] ColSum(int[][] a) 
	{
		int ColSum[] = new int[a.length];
		int index=0;
		for (int i = 0; i < a.length; i++) {
			int sum = 0;
			for (int j = 0; j < a[i].length; j++) {
				sum = sum + a[j][i];
			}
			ColSum[index++]=sum;
		}
		return ColSum;
	}

	private static int[] RowSum(int[][] a) 
	{
		int index=0;
		int RowSum[]=new int[a.length];
		for (int i = 0; i < a.length; i++) 
		{
			int sum=0;
			for (int j = 0; j < a.length; j++) 
			{
				sum=sum+a[i][j];
			}
			RowSum[index++]=sum;
		}
		return RowSum;
	}

	private static int[][] SwappingRow(int[][] a) {
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (i == 0) {
					int t = a[i][j];
					a[i][j] = a[a.length - 1][j];
					a[a.length - 1][j] = t;
				}
			}
		}
		return a;
	}

	private static int[][] SwappingCol(int[][] a) {
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (j == 0) {
					// int x=a[i][j];
					// int y=a[i][a.length-1];
					// int t=x;
					// x=y;
					// y=t;
					int t = a[i][j];
					a[i][j] = a[i][a.length - 1];
					a[i][a.length - 1] = t;
				}
			}
		}
		return a;
	}

	private static int[] leftDiagonal(int[][] a) {
		int ld[] = new int[a.length];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (i + j == a.length - 1) {
					ld[i] = a[i][j];
				}
			}
		}
		return ld;
	}

}
