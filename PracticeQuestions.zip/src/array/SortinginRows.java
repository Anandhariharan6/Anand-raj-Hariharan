package array;

import java.util.Scanner;

public class SortinginRows 
{
	public static int[] bubble(int a[][],int r2[])//bubble sort in descending order
	{
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length-i-1; j++) 
			{
				if(r2[j]<r2[j+1])
				{
					int temp=r2[j];
					r2[j]=r2[j+1];
					r2[j+1]=temp;
				}	
			}
		}
		for (int i = 0; i < r2.length; i++)
		{
			System.out.print(r2[i]+" ");
		}
		System.out.println();
		return r2;
	}
	
	public static int[] insert(int r1 [])//insertion in ascending order
	{
		for (int i = 0; i < r1.length; i++) 
		{
			int j =i-1;
			int key = r1[i];
			while(j>=0 && r1[j]>key)
			{
				r1[j+1]=r1[j];
				j--;
			}
			r1[j+1]=key;
		}
		for (int i = 0; i < r1.length; i++) 
		{
			System.out.print(r1[i]+" ");
		}
		System.out.println();
		return r1;
	}
	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter row");
		int r= in.nextInt();
		System.out.println("enter col");
		int c = in.nextInt();
		int r1[]=new int[r];
		int r2[]=new int[r];
		int con[]= new int[r*c];
		int a[][]=new int[r][c];
		//taking inputs to array
		System.out.println("enter elements of array");
		for (int i = 0; i < a.length; i++)
		{
			for (int j = 0; j < a.length; j++)
			{
				a[i][j]=in.nextInt();
			}
		}
		//taking elements of first row
		for (int i = 0; i < r1.length; i++) 
		{
			int count=0;
			for (int j = 0; j < r1.length; j++) 
			{
				r1[count]=a[0][j];
				count++;
			}
		}
		for (int i = 0; i < r; i++) 
		{
			System.out.print(r1[i]);
		}
		System.out.println();
		
		//taking elements of last row
		for (int i = 0; i < r2.length; i++) 
		{
			int count=0;
			for (int j = 0; j < r2.length; j++) 
			{
				r2[count]=a[r-1][j];
				count++;
			}
		}
		for (int i = 0; i < r; i++) 
		{
			System.out.print(r2[i]);
		}
		System.out.println();
		
		bubble(a,r2);
		insert(r1);
		//storing 1d array back to 2d
		for (int i = 0; i < a.length; i++) 
		{
			 	a[0][i]=r1[i];
			}
			System.out.println();
		//storing 1d array back to 2d	
		for (int i = 0; i < a.length; i++) 
		{
			 a[r-1][i]=r2[i];
			}
			System.out.println();
			
		//printing the modified 2 d array
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++)
			{
				System.out.print(a[i][j]);
			}
			System.out.println();
		}
		//converting modified 2d array to 1d and performing binary search
		int k=0;
		for (int i = 0; i < a.length; i++)
		{
			for (int j = 0; j < a.length; j++) 
			{
				con[k]=a[i][j];
				k++;
			}
		}
		for (int i = 0; i < con.length; i++) 
		{
			System.out.print(con[i]+" ");
		}
		System.out.println();
		//binary search
		System.out.println("enter the key:");
		int key=in.nextInt();
		int low=0;
		int high=con.length-1;
	    int	mid=0;
	    while(low<=high) {
	    	mid=(low+high)/2;
	    if(con[mid]==key)
	    {
	    	System.out.println("Found at: "+(mid+1));
	    	break;
	    	
	    }
	    else if( con[mid]<key)
	    {
	    	low=mid+1;
	    }
	    else
	    	high=mid-1;
	    }
	}
}
