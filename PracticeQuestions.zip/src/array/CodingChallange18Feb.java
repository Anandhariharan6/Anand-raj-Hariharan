package array;

import java.util.Scanner;

public class CodingChallange18Feb {

	static Scanner in = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("enter a:");
		int a = in.nextInt();
		System.out.println("enter b:");
		int b = in.nextInt();
		int x[][] = new int[a][b];
		System.out.println("enter data in x array");
		for (int i = 0; i < a; i++) {
			for (int j = 0; j < b; j++) {
				x[i][j] = in.nextInt();
			}
		}
		System.out.println("enter p:");
		int p = in.nextInt();
		System.out.println("enter r:");
		int r = in.nextInt();
		int r1[] = new int[a + a];
		int y[][] = new int[p][r];
		int res[] = new int[a + a];
		System.out.println("enter data in y array");
		for (int i = 0; i < p; i++) {
			for (int j = 0; j < r; j++) {
				y[i][j] = in.nextInt();
			}
		}

		boolean flag = true;
		while (flag) {
			System.out.println("1.Replace the left diagonal of two-dArray");
			System.out.println("2.Add sum of rows of both matrix and store it in 1 d array");
			System.out.println("3. replace all the evevn elements of 1 d array by -1");
			System.out.println("4.perform binary search on 1 d array and sort it by insertion sort");
			int choice = in.nextInt();
			switch (choice) {
			case 1:
				replaceDiagonal(x, y, a, p);
				break;
			case 2:
				res = addsumofrows(x, y, a);
				for (int i = 0; i < res.length; i++) {
					System.out.println(res[i] + " ");
				}
				break;
			case 3:
				int res1[] = replace(res);
				for (int i = 0; i < res1.length; i++) {
					System.out.println(res1[i]);
				}
				break;
			case 4:
				searching(r1);
				break;
			default:
				flag = false;
				System.out.println("invalid Input");

			}
		}

	}

	private static int[] addsumofrows(int x[][], int y[][], int a) {
		// int add=0;
		int index = 0;
		int r1[] = new int[a + a];
		for (int i = 0; i < x.length; i++) {
			int add = 0;
			for (int j = 0; j < x[i].length; j++) {
				add = add + x[i][j];
			}
			r1[index++] = add;
		}

		for (int i = 0; i < y.length; i++) {
			int add = 0;
			for (int j = 0; j < y[i].length; j++) {
				add = add + y[i][j];
			}
			r1[index++] = add;
		}
		return r1;

	}

	private static boolean searching(int r1[])
	{
		int res[]=sorting(r1);
		System.out.println("enter the Search element");
		int s= in.nextInt();
		for (int i = 0; i < r1.length; i++) 
		{
			if(r1[i]==s)
				return true;
		}
		return false;
	
	
		
		
	}

	private static int[] replace(int r1[])
	{
		for (int i = 0; i < r1.length; i++) 
		{
			if (r1[i] % 2 == 0) 
			{
				r1[i] = -1;
			}
		}
		return r1;

	}

	private static void replaceDiagonal(int x[][], int y[][], int a, int p) {
		int d2[] = new int[p];
		int d1[] = new int[a];
		for (int i = 0; i < x.length; i++) {
			for (int j = 0; j < x[i].length; j++) {
				if (i + j == a - 1)// left diagonal for x
				{
					d1[i] = x[i][j];
				}
			}
		}
		for (int i = 0; i < x.length; i++) {
			System.out.print(d1[i]);
		}
		System.out.println();

		for (int i = 0; i < y.length; i++) {
			for (int j = 0; j < y[i].length; j++) {
				if (i + j == p - 1)// left diagonal for y
				{
					d2[i] = y[i][j];
				}
			}
		}

		for (int i = 0; i < y.length; i++) {
			System.out.print(d2[i]);
		}
		System.out.println();

		for (int i = 0; i < y.length; i++) {
			for (int j = 0; j < y[i].length; j++) {
				if (i + j == a - 1) {
					x[i][j] = d2[i];// Swapping diagonal of y with x
				}
			}
		}

		for (int i = 0; i < y.length; i++) {
			for (int j = 0; j < y[i].length; j++) {
				System.out.print(x[i][j] + " ");
			}
			System.out.println();
		}

		for (int i = 0; i < x.length; i++) {
			for (int j = 0; j < x[i].length; j++) {
				if (i + j == a - 1) {
					y[i][j] = d1[i];// Swapping diagonal of x with y
				}
				System.out.println();
			}
		}
		for (int i = 0; i < y.length; i++) {
			for (int j = 0; j < y[i].length; j++) {
				System.out.print(y[i][j] + " ");
			}
			System.out.println();
		}

	}
	private static int[] sorting(int r1[]) 
	{
		//first insertion sort on 1d array 
		//then linear search
		for (int i = 0; i < r1.length; i++)
		{
			int key=r1[i];
			int j =i-1;
			while(j>=0 && r1[j]>key)
				{
				r1[j+1]=r1[j];
				j--;
				}
			r1[j+1]=key;
		}
		return r1;
		
	}

}
