package array;

import java.util.Scanner;

public class TwoDArraycodingchallangeArpit14march {
	static Scanner in = new Scanner(System.in);
	static int rowsum[];

	public static void main(String[] args) {
		System.out.println("enter the no of rows and coloum you want in the array: ");
		int n = in.nextInt();
		System.out.println("enter the elements of he array:");
		int a[][] = new int[n][n];
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				a[i][j] = in.nextInt();
			}
		}
		boolean flag = true;
		do {
			System.out.println("--MENU---");
			System.out.println("1-SWAPPING DIAGONALS.");
			System.out.println("2-DISPLAYING LARGEST ELEMENT OF EACH ROW.");
			System.out.println("3-SUM OF EACH ROW .");
			System.out.println("4-LARGEST AMONGEST THE SUM.");
			System.out.println("5-EXIT");
			System.out.println("enter your choice");
			int c = in.nextInt();
			switch (c) {
			case 1: {
				int swapped[][] = swapping(a);
				for (int i = 0; i < swapped.length; i++) {
					for (int j = 0; j < swapped[i].length; j++) {
						System.out.print(swapped[i][j] + " ");
					}
					System.out.println();
				}
			}
				break;
			case 2: {
				int[] largest = findMaxEachRow(a);
				for (int i = 0; i < largest.length; i++) {
					System.out.print(largest[i] + " ");
				}
				System.out.println();
			}
				break;
			case 3: {
				rowsum = RowSum(a);
				for (int i = 0; i < rowsum.length; i++) {
					System.out.print(rowsum[i] + " ");
				}
				System.out.println();
			}
			case 4: {
				int maxrowsum = MaxRowSum(rowsum);
				System.out.println(maxrowsum);
			}
				break;
			case 5: {
				flag = false;
			}
				break;
			default:
				System.out.println("ENTER A VALID INPUT.");
				break;
			}
		} while (flag);

	}

	// maximum number in a 1-d array
	private static int MaxRowSum(int[] rowsum2) {
		int maxValue = rowsum2[0];
		for (int i = 1; i < rowsum2.length; i++) {
			if (rowsum2[i] > maxValue) {
				maxValue = rowsum2[i];
			}
		}
		return maxValue;
	}

	// row sum and displaying highest of that sum
	private static int[] RowSum(int[][] a) {
		int index = 0;
		int RowSum[] = new int[a.length];
		for (int i = 0; i < a.length; i++) {
			int sum = 0;
			int rowsum = a[i][0];
			for (int j = 0; j < a.length; j++) {
				sum = sum + a[i][j];
			}
			RowSum[index++] = sum;
		}

		return RowSum;
	}

	// displaying largest element of each row in 2d square matrix}
	private static int[] findMaxEachRow(int[][] a) {
		int[] result = new int[a.length];
		for (int i = 0; i < a.length; i++) {
			int maxNum = a[i][0];
			for (int j = 0; j < a[i].length; j++) {
				if (maxNum < a[i][j]) {
					maxNum = a[i][j];
				}
				result[i] = maxNum;
			}
		}
		return result;

	}

	// Swapping Diagonals
	private static int[][] swapping(int[][] a) {
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a[i].length; j++) {
				if (i == j) {
					int t = a[i][j];
					a[i][j] = a[a.length - i - 1][j];
					a[a.length - i - 1][j] = t;
				}
			}
		}
		return a;
	}
}

