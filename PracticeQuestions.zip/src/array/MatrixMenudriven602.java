package array;

import java.util.Scanner;

public class MatrixMenudriven602 {
	static Scanner in = new Scanner(System.in);
	static int[] con;
	static int[] b;
	public static void main(String[] args) 
	{
		
		System.out.println("enter rows:");
		int r= in.nextInt();
		System.out.println("enter col:");
		int c= in.nextInt();
		int a[][]= new int[r][c];
		System.out.println("enter array elements:");
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++) 
			{
				a[i][j]=in.nextInt();
			}
		}
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		
		
		boolean flag=true;
		while(flag)
		{
			System.out.println("Menu");
			System.out.println("2:Sort all elements of matrix");
			System.out.println("3:use binary search to find out elements");
			System.out.println("4:Display all the even elememts of matrix");
			int choice = in.nextInt();
			switch (choice) 
			{
			case 2:b=sorting(a);
			for (int i = 0; i < a.length; i++) {
				System.out.println(b);
			}
			break;
			case 3:binarysearch(b);
			break;
			case 4:even(b);
			break;
			default:
				System.out.println("invalid input");
			}
		}
		

	}
	private static int[] sorting(int[][] a)
	{
		// TODO Auto-generated method stub
		int k=0;
		int index=0;
		for (int i = 0; i < a.length; i++)
		{
			for (int j = 0; j < a.length; j++) 
			{
				k++;
			}
		}
		int con[]= new int[k];
		for (int i = 0; i < a.length; i++)
		{
			for (int j = 0; j < a.length; j++)
			{
				con[index++]=a[i][j];
			}
		}
		int[] a2=insertionsort(con);
		return a2;
		
	}
	
	public static int[] insertionsort(int con[])
	{
		for (int i = 0; i < con.length; i++) 
		{
			int j =i-1;
			int key = con[j];
			while(j>=0 && con[j]>key)
			{
				con[j+1]=con[j];
				j--;
			}
			con[j+1]=key;
		}
		for (int i = 0; i < con.length; i++) 
		{
			for (int j = 0; j < con.length; j++)
			{
				System.out.print(con[j]+" ");
			}
			System.out.println();
		}
		return con;
		
	}
	public static void binarysearch(int a2[])
	{
		int flag=0,pos=0,low=0,mid;
		int high = a2.length-1;
		System.out.println("enter key");
		int key = in.nextInt();
		while(low<=high)
		{
			mid=(low+high)/2;
			if(key == a2[mid])
			{
				pos=mid;
				flag=1;
				break;
			}
			else if(key>a2[mid])
			{
				low=mid+1;
			}
			else
			{
				high=mid-1;
			}
		}
		if(flag==1)
		{
			System.out.println(pos+1);
		}
		else
		{
			System.out.println("element not found");
		}
	}
	public static void even(int b[])
	{
		for (int i = 0; i <b.length; i++)
		{
			if(b[i]%2==0)
			{
				System.out.println("even elements are:"+b[i]);
			}
		}
	}
}
