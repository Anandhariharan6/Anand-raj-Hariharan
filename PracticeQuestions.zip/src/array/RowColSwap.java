package array;

import java.util.Scanner;

public class RowColSwap 
{
	public static int[] Storing_RES(int Swappedrow[][])
	{
		int k=0;
		int index=0;
		for (int i = 0; i < Swappedrow.length; i++)
		{
			for (int j = 0; j < Swappedrow.length; j++) 
			{
				k++;
			}
			System.out.println(k);
		}
		int []d= new int[k];
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++) 
			{
				d[index++]=Swappedrow[i][j];           //2d to 1 d converted
			}
		}
		return d;
	}

	public static int[][] Swap_row_resultant(int Swappedcol[][]) 
	{
		int rtemp=0;
		for (int i = 0; i < r; i++)
		{
			for (int j = 0; j <c; j++) 
			{
				if((i==0) || (i==r-1))
				{
					rtemp=a[i][j];
					a[i][j]=a[r-1][j];
					a[r-1][j]=rtemp;
				}
			}
		}
		return a;
		
	}

	public static int[][] Swap_col(int a[][],int r) 
	{
		int ctemp=0;
		for (int i = 0; i < r; i++) 
		{
			for (int j = 0; j < c; j++) 
			{
				if((j==0) || (j==r-1))
				{
					ctemp=a[i][j];
					a[i][j]=a[i][r-1];
					a[i][r-1]=ctemp;
				}
			}
			System.out.println();
		}
		
		return a;
		
	}
	static Scanner in = new Scanner(System.in);
	static int r;
	static int c;
	static int[][] a;
	static int result[];
	static int Swappedcol[][]= new int[r][c];
	static int Swappedrow[][]= new int[r][c];
	public static void main(String[] args) 
	{
		
		System.out.println("enter rows:");
		 r= in.nextInt();
		System.out.println("enter col:");
		c= in.nextInt();
		 a= new int[r][c];
		System.out.println("enter array elements:");
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++) 
			{
				a[i][j]=in.nextInt();
			}
		}
		for (int i = 0; i < a.length; i++) {
			for (int j = 0; j < a.length; j++) {
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		
		boolean flag=true;
		while(flag)
		{
			System.out.println("Menu");
			System.out.println("1:Swapping the col");
			System.out.println("2:Swapping the rows of resultant matrix from 1");
			System.out.println("3:Storing the resultant matrix from 2 in a 1D matrix");
			int choice = in.nextInt();
			switch (choice) 
			{
			case 1:Swappedcol=Swap_col(a,r);
			for (int i = 0; i <r; i++)
			{
				for (int j = 0; j <c; j++)
				{
					System.out.print(a[i][j]+" ");
				}
				System.out.println();
			}
			break;
			case 2:Swappedrow=Swap_row_resultant(Swappedcol);
			for (int i = 0; i <r; i++)
			{
				for (int j = 0; j <c; j++)
				{
					System.out.print(a[i][j]+" ");
				}
				System.out.println();
			}
			break;
			case 3:result=Storing_RES(Swappedrow);
			for (int i = 0; i < result.length; i++)
			{
				System.out.print(result[i]);
			}
			System.out.println();
			break;
			default:
				System.out.println("invalid input");
			}
		}
		

	}

}
