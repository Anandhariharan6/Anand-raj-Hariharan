package array;
import java.util.Scanner;
public class SwappingRowAndStoringiniDAray 
{
	static Scanner in = new Scanner(System.in);
	public static void main(String[] args) 
	{
		System.out.println("enter a:");
		int a =in.nextInt();
		System.out.println("enter b:");
		int b = in.nextInt();
		int x[][] = new int[a][b];
		System.out.println("enter data in x array");
		for (int i = 0; i < a; i++)
		{
			for (int j = 0; j < b; j++)
			{
				x[i][j]= in.nextInt();
			}
		}
		int temp;
		for (int i = 0; i < x.length; i++)
		{
			for (int j = 0; j < x[i].length; j++)
			{
				if((i==0) || (i==a-1))
				{
					temp =x[i][j];
					x[i][j]=x[a-1][j];
					x[a-1][j]=temp;
				}
			}
			System.out.println();
		}
		
		for (int i = 0; i < x.length; i++)
		{
			for (int j = 0; j < x[i].length; j++)
			{
				System.out.print(x[i][j]+" ");
			}
			System.out.println();
		}
		int r1[]=new int[x.length*x.length];
		int c=0;
		for (int i = 0; i < x.length; i++) 
		{
			for(int j=0;j<x[i].length;j++)
			{
			if(x[i][j]%2==0)
			{   
				r1[c]=x[i][j];
				c++;
			}
			}
		}
		for (int i = 0; i <c; i++) 
		{
			System.out.print(r1[i]);
		}
		System.out.println();
		
		
//		int r2[]=new int[a];
//		for (int i = 0; i < x.length; i++)
//		{
//			for (int j = 0; j < x[i].length; j++)
//			{
//				if(i==a-1) 
//				{
//					r2[i]=x[i][j];
//				}
//			}
//			System.out.println();
//		}
//		for (int i = 0; i < x.length; i++) 
//		{
//			System.out.print(r2[i]);
//		}
	}
}
