package array;

import java.util.Scanner;
//modular approach
public class SumOfAlltheElementsInArray {
	static Scanner in = new Scanner(System.in);
	
	public static void main(String[] args) {
		System.out.println("enter the no of elements yo want in an array");
		int size = in.nextInt();
		int sum[] = new int [size];
		int res[] = addingElementsofArray(sum);
		int result = summation(res);
		System.out.println(result);
	}

	private static int[] addingElementsofArray(int[] sum) {
		int[] add = new int[sum.length];
		for (int i = 0; i < add.length; i++)
		{
			System.out.println("enter the elements of the array"+i );
			add[i]=in.nextInt();
		}
		return add;
	}

	private static int summation(int[] res) {
		int s=0;
		for (int i = 0; i < res.length; i++) 
		{
			s=s+res[i];
		}
		return s;
	}

	

}
