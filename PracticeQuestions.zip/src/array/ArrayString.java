package array;

import java.util.Scanner;

public class ArrayString {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter the no. of names you want = :");
		int n = in.nextInt();
		String x[] = new String[n];
		for (int i = 0; i < x.length; i++)
		{
			System.out.println("enter the names in "+(i)+" th position = ");
			x[i]=in.next();
		}
		for (int i = 0; i < x.length; i++) 
		{
			System.out.println("the names you entered are = "+x[i]);
		}

	}

}
