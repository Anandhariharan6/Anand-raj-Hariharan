package array;

import java.util.Scanner;

public class TwoDArrayDynamicInput {
	static Scanner in = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("enter a:");
		int a =in.nextInt();
		System.out.println("enter b:");
		int b = in.nextInt();
		int x[][] = new int[a][b];
		for (int i = 0; i < x.length; i++)
		{
			for (int j = 0; j < x[i].length; j++)
			{
				System.out.println("enter data in x["+i+" "+j+"]position");
				x[i][j]= in.nextInt();
			}
		}
//		for (int i = 0; i < x.length; i++)
//		{
//			for (int j = 0; j < x[i].length; j++)
//			{
//				x[i][j]= in.nextInt();
//				System.out.print(x[i][j]);
//			}
//			System.out.println();
//		}
		for (int i = 0; i < x.length; i++)
		{
			for (int j = 0; j < x[i].length; j++) 
			{
				if(i==j)
				System.out.print("right diagonal = "+x[i][j]);
			}
			System.out.println();
		}
//		System.out.println("==========");
//		for (int i = 0; i < x.length; i++)
//		{
//			System.out.println("right diagonal = "+x[i][i]);
//		}
		System.out.println();
		System.out.println("==========");
		for (int i = 0; i < x.length; i++)
		{
			for (int j = 0; j < x[i].length; j++) 
			{
				if(i+j==a-1)
				System.out.print("left diagonal = "+x[i][j]);
				
			}
			System.out.println();
		}
		System.out.println("============");
		for (int i = 0; i < x.length; i++)
		{
			for (int j = 0; j < x[i].length; j++) 
			{
				if(i==0 || i==a-1 || j==0 || j==a-1)
				{
				System.out.print(x[i][j]);
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println();
		}
		System.out.println("===========");
		int sum=0;
		for (int i = 0; i < x.length; i++)
		{
			for (int j = 0; j < x[i].length; j++) 
			{
				if(i==j)
				{
					sum=sum+x[i][j];
				} 
			}
			System.out.println();
		}
		System.out.print("sum of right diagonal = "+sum);
	}
}
