package array;

import java.util.Scanner;

public class ArrayPower {
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter the size of the array:");
		int size = in .nextInt();
		System.out.println("enter power");
		int power = in.nextInt();
		int a[]= new int[size];
		for (int i = 0; i < a.length; i++) 
		{
			System.out.println("enter the elements of "+(i)+"th position:");
			a[i]=in.nextInt();
		}
		
		
		
	}
}
