package array;

import java.util.Scanner;

import javax.swing.text.StyledEditorKit.ForegroundAction;

public class MatrixMultiplication6thfeb 
{
	static Scanner in = new Scanner(System.in);

	public static void main(String[] args)
	{

		System.out.println("enter no of row for first matrix:");
		int a =in.nextInt();
		System.out.println("enter no of col for first matrix:");
		int b = in.nextInt();
		int x[][] = new int[a][b];
		int sum[][]=new int[x.length][x.length];		
		int o[]=new int[x.length*x.length];
		System.out.println("enter data in x array");
		for (int i = 0; i < a; i++)
		{
			for (int j = 0; j < b; j++)
			{
				x[i][j]= in.nextInt();
			}
		}
		System.out.println("enter no of row for first matrix:");
		int p =in.nextInt();
		System.out.println("enter no of col for second matrix:");
		int r = in.nextInt();
		int y[][] = new int[p][r];
		System.out.println("enter data in y array");
		for (int i = 0; i < p; i++)
		{
			for (int j = 0; j < r; j++)
			{
				y[i][j]=in.nextInt();
			}
		}
		boolean flag=true;
		while(flag)
		{
			System.out.println("menu");
			System.out.println("1:multiplication");
			System.out.println("2:conversion of 2D to 1D");
			System.out.println("3:sorting");
			System.out.println("4.searching");
			int choice = in.nextInt();
			switch(choice)
			{
			case 1: sum=multiply(x,y,p,b);
			for(int i=0;i<sum.length;i++)
			{
				for(int j=0;j<sum.length;j++)
				{
					System.out.print(sum[i][j]+" ");
				}
				System.out.println();
			}
			
			break;
			case 2:o=conversion(sum,x);
			for(int i=0;i<o.length;i++)
			{
				System.out.print(o[i]+" ");
			}
			System.out.println();
			break;
			case 3:o=sorting(o);
			for(int i=0;i<o.length;i++)
			{
				System.out.print(o[i]+" ");
			}
			System.out.println();
			break;
			case 4:
				System.out.println("enter key");
				int key = in.nextInt();
				int mid=searching(o,key);
			if(mid>0)
			{
				System.out.println("Element found at "+mid);
			}
			else
			{
				System.out.println("element not found");
			}
			break;
			default:flag=false;
			System.out.println("enter a valid input");	
			}
		}
	}
	public static int[][] multiply(int x[][],int y[][],int p,int b)
	{
		int c[][]=new int[b][p];
		for (int i = 0; i < b; i++)
		{
			for (int j = 0; j < p; j++) 
			{
					 c[i][j] =  (x[i][j] * y[j][i]);//multiplication formula
				}
			}
//		for (int i = 0; i < c.length; i++)
//		{
//			for (int j = 0; j < c.length; j++) 
//			{
//				System.out.print(c[i][j]+" ");
//			}
//			System.out.println();
//		}
		return c;
		
	}
	public static int[] conversion(int c[][], int x[][])
	{
		int k=0;
		int index=0;
		for (int i = 0; i < c.length; i++) 
		{
			for (int j = 0; j < c.length; j++) 
			{
				k++;					//converting 2D to 1D array checking the size of the resultant 1D array
			}
		}
		int o[]=new int[k];
		for (int i = 0; i < x.length; i++) 
		{
			for (int j = 0; j < x.length; j++)
			{
				o[index++]=c[i][j];				//converted 1D Array
			}
		}
//		for (int i = 0; i < o.length; i++) 
//		{
//			System.out.print(o[i]+" ");
//		}
//		System.out.println();
		return o;
	}
	
	public static int[] sorting(int o[])
	{
		//performing insertion sort
		for (int i = 1; i < o.length; i++) 
		{
			int key = o[i];
			int j =i-1;
			while(j>=0 && o[j]>key)
			{
				o[j+1]=o[j];
				j--;
			}
			o[j+1]=key;
		}
//			for (int j = 0; j < o.length; j++)
//			{
//				System.out.print(o[j]+" ");
//			}
//			System.out.println();
			return o;
	}
	public static int searching (int o[],int key) 
	{
//		for (int i = 0; i < o.length; i++) 
//		{
//			System.out.print(o[i]+" ");
//		}
//		System.out.println();
//			
		int flag=0,pos=0,low=0,mid;
		int high = o.length-1;
		
		while(low<=high)
		{
			mid=(low+high)/2;
			if(key == o[mid])
			{
				pos=mid;
				return mid;
			}
			else if(key>o[mid])
			{
				low=mid+1;
			}
			else
			{
				high=mid-1;
			}
		}
		return -1;
		
	}
	

	}



