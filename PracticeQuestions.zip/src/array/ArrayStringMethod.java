package array;

import java.util.Scanner;

public class ArrayStringMethod {
	static Scanner in = new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("enter the size of the String arry you want = ");
		int size = in.nextInt();
		//taking user input for the size of array
		
		String name[] = new String[size]; //we take a new string array
		//insert data in array
		
		String [] vessel = insertDataInArray(name); //creating method in the resultant array
		//printing values of the array
		
		for (int i = 0; i < vessel.length; i++) {
			System.out.println(vessel[i]);
		}
	}

	private static String[] insertDataInArray(String[] name) {
		//create result
		String[] result = new String[name.length];
		//update result
		for (int i = 0; i < result.length; i++) 
		{
			System.out.println("enter data to "+(i)+" th position :");
			result[i] = in.next();
		}
		//return result
		return result;
	}

}
