package array;

import java.util.Scanner;

public class TwoDArrayTest {
	static Scanner in = new Scanner(System.in);
	public static void main(String[] args) {
		int[][] x = {{1,2,3},{3,4,5},{4,5,6}};
//		int []y = {9,6,4};
//		System.out.println(y[0]);
//		System.out.println(x[1][2]);
		for (int i = 0; i < x.length; i++) {
			for (int j = 0; j < x[i].length; j++)
			{
				System.out.print(x[i][j] +" ");
			}
			System.out.println();
		}
		
	}

}
