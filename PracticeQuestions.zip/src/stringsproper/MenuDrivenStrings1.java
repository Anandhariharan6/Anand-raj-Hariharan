package stringsproper;

import java.util.Scanner;

public class MenuDrivenStrings1
{
	static Scanner in = new Scanner(System.in);
	
		public static void main(String[] args) 
		{
			System.out.println("Enter A string");
			String s=in.nextLine();
			boolean flag=true;
			while(flag)
			{
				System.out.println("1: Special char in place of Spaces");
				System.out.println("2: First and last alphabet of a word");
				System.out.println("3: Replacing Even char of a String");
				int count=in.nextInt();
				switch(count)
				{
				case 1:Specialchar(s);
				break;
				case 2:FirstAndLast(s);
				break;
				case 3:EvenChar(s);
				}
			}
		}
		
		private static String Specialchar(String s)
		{
			String s1="";
			for (int i = 0; i < s.length(); i++) 
			{
				if(s.charAt(i)==' ') 
				{
					s1=s1+'@';
				}
				else
				{
					s1=s1+s.charAt(i);
				}
			}
			System.out.println(s1);
			return s1;
		}
		
		private static String FirstAndLast(String s) 
		{
			String s2="";
			System.out.println(s.charAt(0));
			for (int i = 0; i < s.length(); i++)
			{
				if(s.charAt(i)==' ')
				{
					System.out.print(s.charAt(i-1));
					System.out.print(" ");
					System.out.print(s.charAt(i+1));
				}
			}
			System.out.println(s.charAt(s.length()-1));
			return s2;	
		}

		
		
		private static String EvenChar(String s) 
		{
			String s3="";
			char c=0;
			for (int i = 0; i < s.length(); i++) 
			{
				if(s.charAt(i)%2==0 && s.charAt(i)!=0)
				{
					c=(char)(s.charAt(i)+1);
					s3=s3+c;
				}
				else
				{
					s3=s3+s.charAt(i);
				}
			}
			System.out.println(s3);
			return s3;
			
		}		
		
}

