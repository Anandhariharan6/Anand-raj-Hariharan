package stringsproper;

import java.util.Scanner;

public class CheckPalindrome {
	public static void palindrome(String s)
	{
		String rev="";
		for (int i =0; i < s.length(); i++)
		{
			rev = s.charAt(i)+rev;
		}
		if(s.equals(rev))
		{
			System.out.println("Is Palindrome");
		}
		else
		{
			System.out.println("not Palindrome");
		}
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a String to check palindrome");
		String s= in.nextLine();
		palindrome(s);

	}

}
