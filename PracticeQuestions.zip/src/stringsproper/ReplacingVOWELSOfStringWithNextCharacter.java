package stringsproper;

import java.util.Scanner;

public class ReplacingVOWELSOfStringWithNextCharacter {
	static Scanner in = new Scanner(System.in);
	public static void main(String[] args)
	{

		System.out.println("enter a String");
		String str = in.nextLine();
		String[] s=split(str);
		String res="";
		for(int i=0;i<s.length;i++)
		{      
			for(int j=0;j<s[i].length();j++)
			{ 
				//NEW ONE
				if("aeiouAEIOU".indexOf(s[i].charAt(j))>=0)
				{	
				res+=(char)(s[i].charAt(j)+1);
				}
				else
				{
				res+=s[i].charAt(j);
				}		
			}
		}
		System.out.println(res);
	}
	
	
	
	
	public static String[] split(String str)
{
	int count=0;
	String word=" ";
	for (int i = 0; i < str.length(); i++)
	{
		if(str.charAt(i)==' ')
		{
			continue;
		}
		else
		{
			count++;
			while(i<str.length() && str.charAt(i)!=' ')
			{
				i++;
			}
		}
	}
	int k=0;
	String[] s=new String[count];
	for (int i = 0; i < str.length(); i++) 
	{
		if(str.charAt(i)==' ')
		{
			continue;
			}
		else
		{
			word="";
			while(i<str.length() && str.charAt(i)!=' ')
			{
				word=word+str.charAt(i);
				i++;
			}s[k++]=word;
		}
	}
	return s;
}
}
