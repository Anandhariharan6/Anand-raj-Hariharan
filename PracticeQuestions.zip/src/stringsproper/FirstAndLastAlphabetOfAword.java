package stringsproper;

import java.util.Scanner;

public class FirstAndLastAlphabetOfAword {
	public static String firstlast(String str)
	{
		System.out.print(str.charAt(0));
		for (int i = 0; i < str.length(); i++) 
		{
			if(str.charAt(i)==' ')
			{
				System.out.print(str.charAt(i-1)+" ");
				System.out.print(" ");
				System.out.print(str.charAt(i+1));
			}
		}
		System.out.println(str.charAt(str.length()-1));
		return str;
	}

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter a String");
		String str = in.nextLine();
		 firstlast(str);
	}

}
