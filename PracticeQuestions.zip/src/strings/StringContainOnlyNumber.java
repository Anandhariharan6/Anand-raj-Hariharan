package strings;

import java.util.Scanner;

public class StringContainOnlyNumber {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter a string : ");
		String s = in.next();
		boolean flag = true;
		for (int i = 0; i < s.length(); i++) 
		{
			if(s.charAt(i)< 48 || s.charAt(i)> 57)
			{
				flag = false;
				break;
			}
		}
		if(flag = true)
		{
			System.out.println("only numbers present");
		}
		else
		{
			System.out.println("Other  digits are also present");
		}

	}

}
