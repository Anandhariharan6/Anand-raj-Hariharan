package strings;

import java.util.Scanner;

public class String2DmatrixManipulation {
	public static String[][] stringmatrix(String a[][])
	{
		for (int i = 0; i < a.length; i++)
		{
			for (int j = 0; j < a.length; j++) 
			{
				System.out.print(a[i][j] + " ");
			}
			System.out.println();
		}
		return a;
	}

	public static String[] conversion(String matrix[][]) 
	{
		int k = 0;
		int index = 0;
		for (int i = 0; i < matrix.length; i++) 
		{
			for (int j = 0; j < matrix.length; j++) 
			{
				k++;
			}
		}
		String o[] = new String[k];
		for (int i = 0; i < matrix.length; i++) 
		{
			for (int j = 0; j < matrix.length; j++) 
			{
				o[index++] = matrix[i][j];
			}
		}
		return o;
	}

	// public static String[] sorting()
	// {
	// char c=0;
	// for (int i = 0; i < converted.length; i++)
	// {
	// for (int j = 0; j < converted.length-i-1; j++)
	// {
	// if(converted[j].length()>converted[j+1].length())
	// {
	// String temp = converted[j];
	// converted[j]= converted[j+1];
	// converted[j+1]= temp;
	// }
	// }
	// }
	// return converted;
	// }

	public static String[] sorting(String[] converted)
	{
		for (int i = 0; i < converted.length; i++) 
		{
			for (int j = 0; j < converted.length - i - 1; j++)
			{
				if (converted[j + 1].compareTo(converted[j]) > 0) 
				{
					String temp = converted[j];
					converted[j] = converted[j + 1];
					converted[j + 1] = temp;
				}
			}
		}
		return converted;
	}

	// public static String[] sorting()
	// {
	// boolean flag=true;
	// while(flag)
	// {
	// flag=false;
	// }
	// for (int j = 0; j < converted.length; j++)
	// {
	// if(converted[j-1].compareTo(converted[j])>0)
	// {
	// String temp = converted[j-1];
	// converted[j-1]= converted[j];
	// converted[j]= temp;
	// flag=true;
	// }
	// }
	// return converted;
	// }
//	public static void onetoTwo(String sorted[], int n) {
//		String[] res=sorted;
//		for (int i = 0; i < res.length; i++) {
//			System.out.println(res[i]);
//		}
////		int c = 0;
////		for (int i = 0; i < sorted.length; i++) {
////			for (int j = 0; j < sorted.length; j++) {
////					tt[i][j] = res[c];
////					c++;
////				}
////			}
//
//		


	static Scanner in = new Scanner(System.in);
	static String[][] matrix;
	static String[] converted;
	static String[] sorted;
	static String[][] result;

	public static void main(String[] args) {

		System.out.println("enter col & rows of matrix");
		int n = in.nextInt();
		in.nextLine();
		String a[][] = new String[n][n];
		System.out.println("enter array elements:");
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++) 
			{
				a[i][j] = in.next();
			}
		}

		boolean flag = true;
		while (flag) {
			System.out.println("1. Create a 2D matrix of String type of size NxN.");
			System.out.println("2. Conversion of 2D matrix to 1D matrix");
			System.out.println("3. Sort on basis of length of the string");
			System.out.println("4. Conversion of 1D to 2D matrix");
			int choice = in.nextInt();
			switch (choice) {
			case 1:
				matrix = stringmatrix(a);
				break;

			case 2:
				converted = conversion(matrix);
				for (int i = 0; i < converted.length; i++)
				{
					System.out.print(converted[i] + " ");
				}
				System.out.println();
				break;
				

			case 3:
				sorted = sorting(converted);
				for (int i = 0; i < sorted.length; i++) {
					System.out.print(sorted[i] + " ");
				}
				System.out.println();
				break;
			case 4:
//      		onetoTwo(sorted, n);
//				result = onetoTwo(sorted, n);
				for (int i = 0; i < a.length; i++) {
					for (int j = 0; j < a.length; j++) {
						System.out.print(a[i][j] + " ");
					}
					System.out.println();
				}

				break;
			default:
				System.out.println("invalid input");
			}
		}

	}

}
