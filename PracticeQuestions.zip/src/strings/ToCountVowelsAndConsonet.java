package strings;

import java.util.Scanner;

public class ToCountVowelsAndConsonet 
{
	public static void countv(String s)
	{
		String vowels="";
		String consonents="";
		int vcount=0;
		int ccount=0;
		for (int i = 0; i < s.length(); i++)
		{
			if(s.charAt(i)=='a' ||s.charAt(i)== 'e' || s.charAt(i)=='i' || s.charAt(i)=='o' || s.charAt(i)=='u' 
					 || s.charAt(i)=='A' ||s.charAt(i)== 'E' || s.charAt(i)=='I' || s.charAt(i)=='O' || s.charAt(i)=='U' )
			{
				vowels=vowels+s.charAt(i);
				++vcount;
			}
			
			else
			{
				
				consonents=consonents+s.charAt(i);
				++ccount;
			}
		}
		System.out.println("vowels are: "+vcount);
		System.out.println("consonents are: "+ccount);
	}
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter a String");
		String s= in.nextLine();
		countv(s);
	}
}
