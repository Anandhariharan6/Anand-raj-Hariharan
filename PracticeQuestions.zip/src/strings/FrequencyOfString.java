
	package strings;

	import java.util.Scanner;

	public class FrequencyOfString
	{
		public static void main(String[] args)
		{
		        String str, str1;
		        char c, ch;
		        Scanner in = new Scanner(System.in);
		        
		        System.out.print("Enter a String : ");
		        str=in.nextLine();
		        
		        for(c='A'; c<='z'; c++)
		        {
		            int k=0;
		            for( int j=0; j<str.length(); j++)
		            {
		                ch = str.charAt(j);
		                if(ch == c)
		                {
		                    k++;
		                }
		            }
		            if(k>0)
		            {
		                System.out.println("The character " + c + " has occurred for " + k + " times");
		            }
			}
		}
	}

