package strings;

import java.util.Scanner;

public class StringContainsOnlyChar {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter a character : ");
		String s = in.next();
		boolean flag = false;
		for (int i = 0; i < s.length(); i++) 
		{
			if((s.charAt(i)<=97 || s.charAt(i)>=122) && (s.charAt(i)<=65 || s.charAt(i)>=90))
			{
				flag = true;
				break;
			}
		}
		if(flag == false)
		{
			System.out.println("only char are  present");
		}
		else
		{
			System.out.println("Other  digits are also present");
		}

	}

}
