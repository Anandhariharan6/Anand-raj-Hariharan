package strings;

import java.util.Scanner;

public class StringMenuWorld15thmarch {
	static Scanner in =new Scanner(System.in);
	public static void main(String[] args) 
	{
		System.out.println("enter a String:");
		String str=in.nextLine();
		String s[]=split(str);
		boolean flag =true;
		do {
			System.out.println("---MENU---");
			System.out.println("1-printing the next element of the entered input.");
			System.out.println("2-printing the next element of the even indexes.");
			System.out.println("3-printing the next element of the odd indexes.");
			System.out.println("4-printing the even char at upper and odd at lower.");
			System.out.println("5-hello world -- horlo welld");
			System.out.println("enter choice");
			int c= in.nextInt();
			switch (c) {
			case 1:
			{
				String []previous=Previous(s);
				for (int i = 0; i < previous.length; i++) 
				{
					System.out.print(previous[i]);
				}
				System.out.println();
			}
				break;
			case 2:
			{
				String[] two=odd(s);
				for (int i = 0; i < two.length; i++) 
				{
					System.out.print(two[i]);
				}
				System.out.println();
			}
			break;
			case 3:
			{
				String[] three=even(s);
				for (int i = 0; i < three.length; i++) 
				{
					System.out.print(three[i]);
				}
				System.out.println();
			}
			break;
			case 4:
			{
				String[] four=CapsAtEvenPlaces(s);
				for (int i = 0; i < four.length; i++) 
				{
					System.out.print(four[i]);
				}
				System.out.println();
			} 
			break;
			case 5:
			{
				String[] five=Swap(s);
			}
			break;
			default:
				System.out.println("enter avalid input");
				break;
			}
			
		} while (flag);

	}
	
	public static void  split2(String str)
{
	int count=0;
	String word=" ";
	for (int i = 0; i < str.length(); i++)
	{
		if(str.charAt(i)==' ')
		{
			continue;
		}
		else
		{
			count++;
			while(i<str.length() && str.charAt(i)!=' ')
			{
				i++;
			}
		}
	}
	if(count==2)
	{
	int k=0;
	String[] s=new String[count];
	for (int i = 0; i < str.length(); i++) 
	{
		if(str.charAt(i)==' ')
		{
			continue;
			}
		else
		{
			word="";
			while(i<str.length() && str.charAt(i)!=' ')
			{
				word=word+str.charAt(i);
				i++;
			}s[k++]=word;
		}
	}
	String res="";
	String res2="";
	int a=s[0].length();
	int b=s[1].length();
	res+=s[0].charAt(0);
	for(int i=0;i<b-1;i++)
	{
		res+=s[1].charAt(j);
	}
	res+=s[0].charAt(a);
	res2+=s[1].charAt(0);
	for(int i=0;i<b-1;i++)
	{
		res2+=s[0].charAt(j);
	}
	res2+=s[1].charAt(b);
	
			}
	
	
	
	
	
	
	System.out.println(res+" "+res2);
}
	private static String[] CapsAtEvenPlaces(String[] s) 
	{
		String [] p=new String[s.length];
		String p1="";
		int k=0;
		for (int i = 0; i < s.length; i++) 
		{
			for (int j = 0; j < s[i].length(); j++)
			{
				if(j%2==0 && s[i].charAt(j)>='a' && s[i].charAt(j)<='z')
				{
					int as=s[i].charAt(j);
				    as=as-32;
					char ch=(char)as;
					p1=p1+ch;
					
				}
				else if(j%2!=0 && s[i].charAt(j)>='A' &&s[i].charAt(j)<='Z')
				{
					int as=s[i].charAt(j);
				    as=as+32;
					char ch=(char)as;
					p1=p1+ch;
					
				}
				
				else
				{
					p1+=s[i].charAt(j);
				}
			}
			p[k++]=p1;
			p1=" ";
		}
		return p;
	}

	private static String[] even(String[] s) 
	{
		String[] p=new String[s.length];
		String p1="";
		int k=0;
		for (int i = 0; i < s.length; i++) 
		{
			for (int j = 0; j < s[i].length(); j++)
			{
				if(j%2!=0 )
				{
					int as=s[i].charAt(j);
				    as=as+1;
					char ch=(char)as;
					p1=p1+ch;
				}
				else
				{
					p1+=s[i].charAt(j);
				}
			}
			p[k++]=p1;
			p1=" ";
		}
		return p;
	}

	private static String[] odd(String[] s) 
	{
		String[] p=new String[s.length];
		String p1="";
		int k=0;
		for (int i = 0; i < s.length; i++) 
		{
			for (int j = 0; j < s[i].length(); j++)
			{
				if(j%2==0 )
				{
					int as=s[i].charAt(j);
				    as=as+1;
					char ch=(char)as;
					p1=p1+ch;
				}
				else
				{
					p1+=s[i].charAt(j);
				}
			}
			p[k++]=p1;
			p1=" ";
		}
		return p;
	}

	private static String[] Previous(String[] s) 
	{
		String[] p=new String[s.length];
		String p1="";
		int k=0;
		for (int i = 0; i < s.length; i++) 
		{
			for (int j = 0; j < s[i].length(); j++)
			{
				
				{
					int as=s[i].charAt(j);
				    as=as+1;
					char ch=(char)as;
					p1=p1+ch;
				}
			}
			p[k++]=p1;
			p1=" ";
		}
		return p;
	}
	public static String[] split(String str)
{
	int count=0;
	String word=" ";
	for (int i = 0; i < str.length(); i++)
	{
		if(str.charAt(i)==' ')
		{
			continue;
		}
		else
		{
			count++;
			while(i<str.length() && str.charAt(i)!=' ')
			{
				i++;
			}
		}
	}
	int k=0;
	String[] s=new String[count];
	for (int i = 0; i < str.length(); i++) 
	{
		if(str.charAt(i)==' ')
		{
			continue;
			}
		else
		{
			word="";
			while(i<str.length() && str.charAt(i)!=' ')
			{
				word=word+str.charAt(i);
				i++;
			}s[k++]=word;
		}
	}
	return s;
}

}
