package strings;

import java.util.Scanner;

public class BinarySearch
{ static Scanner in = new Scanner(System.in);
	
	
	public static void main(String[] args) 
	{
		System.out.println("Binary searh");
		System.out.println("-------------");
		boolean flag=true;
		do
		{
			System.out.println("\n1-for Integer\n2-for strings\n3-exit");
			
			int choice=in.nextInt();
			switch(choice)
			{
			case 1:findElement();
			break;
			case 2: findString();
			break;
			case 3:flag=false;
			break;
			default:
			System.out.println("invalid");
			}
		}while(flag==true);
		
		}
		
	
	private static void findString() 
	{
		System.out.println("enter the size of the array");
		int s = in.nextInt();
		System.out.println("enter the strings");
		String a2[]=new String[s];
		for (int i = 0; i < a2.length; i++) 
		{
			a2[i]=in.next();
		}
		System.out.println("enter the search element");
		int mid=0;
		int low=0;
		int high=a2.length-1;
		String key = in.next();
		while(low<=high)
		{
			mid = (low + high)/2;
			if(a2[mid].equals(key))
			{
				System.out.println("found at:"+(mid+1));
				break;
			}
			else if(key.compareTo(a2[mid])>0)
			{
				low = mid + 1;
			}
			else {
				high = mid-1;
			}
			if(low>high)
			{
				System.out.println("String is not found");
			}
		}
	}


	private static void findElement() 
	{
		// TODO Auto-generated method stub
		System.out.println("enter the size of the array");
		int s = in.nextInt();
		System.out.println("enter the elements");
		int a1[]=new int[s];
		for (int i = 0; i < a1.length; i++) 
		{
			a1[i]=in.nextInt();
		}
		System.out.println("enter the search element");
		int mid=0;
		int low=0;
		int high=a1.length-1;
		int key = in.nextInt();
		while(low<=high)
		{
			mid = (low + high)/2;
			if(a1[mid]==key)
			{
				System.out.println("found at:"+(mid+1));
				break;
			}
			else if(key>a1[mid])
			{
				low = mid + 1;
			}
			else {
				high = mid-1;
			}
			if(low>high)
			{
				System.out.println("String is not found");
			}
	}

	}
	public static void Array() {
		// TODO Auto-generated method stub
		
	}


//	public static String String() 
//	{
//		System.out.println("enter the size of the array");
//		int s = in.nextInt();
//		System.out.println("enter the strings");
//		String a1[]=new String[s];
//		for (int i = 0; i < a1.length; i++) 
//		{
//			a1[i]=in.next();
//		}
//		int mid=0;
//		int low=0;
//		int high=a1.length-1;
//		System.out.println("enter the search element");
//		String key = in.next();
//		while(low<=high)
//		{
//			mid = (low + high)/2;
//			if(a1[mid].equals(key))
//			{
//				System.out.println("found at:"+(mid+1));
//				break;
//			}
//			else if(a1[mid].compareTo(key)>0)
//			{
//				low = mid + 1;
//			}
//			else {
//				high = mid-1;
//			}
//		}
//		
//		
//		return null;
//	}
}
