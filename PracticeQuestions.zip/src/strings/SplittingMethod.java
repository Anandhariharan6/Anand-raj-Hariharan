package strings;

import java.util.Scanner;

public class SplittingMethod 
{
	public static String[] split(String s)
	{
		//String s=trim(untrimmed);
		System.out.println("Im printing"+s);
		int c=0;
		for (int i = 0; i < s.length(); i++)
		{
			if(s.charAt(i)==' ')
			{
			c++;
			}
		}
		String split[]=new String [c+1];
		String str="";
		int index=0;
		for (int i = 0; i < s.length(); i++)
		{
			if(s.charAt(i)==' ')
			{
				split[index++]=str;
				str="";
			}
			else
			{
				str=str+s.charAt(i);
			}
		}
		split[index++]=str;
		
		return split;
	}
	
//	private static String trim(String untrimmed) {
//		// TODO Auto-generated method stub
//		String trimmed="";
//		for (int i = 0; i < untrimmed.length()-1; i++) {
//			if((untrimmed.charAt(i+1)!=' '&&untrimmed.charAt(i)!=' '))
//			{
//				System.out.println(i+" "+trimmed);
//				trimmed=trimmed+untrimmed.charAt(i);
//			}
//			else
//			{
//				
//			}
//		}
//		return trimmed;
//	}

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter a string");
		String s = in.nextLine();
		String arr[]= split(s);
		for (int i = 0; i < arr.length; i++) 
		{
			System.out.println(arr[i]);
		}
		System.out.println();
		//String t=replace(s);
		for (int i = 0; i < arr.length; i++) {
			String s1=arr[i];
			String t="";
			for(int j=1;j<s1.length()-1;j++)
			{
				t=t+s1.charAt(j);
			}
			t=s1.charAt(s1.length()-1)+t+s1.charAt(0);
			arr[i]=t;
		}
//		for (int i = 0; i < arr.length; i++) {
//			arr[i]=replace(arr[i]);
//		}
		for (int i = 0; i < arr.length; i++) 
		{
			System.out.println(arr[i]);
		}
	}

	public static String replace(String s) 
	{
		String t="";
		for (int i = 1; i < s.length()-1; i++) 
		{
			t=t+s.charAt(i);
		}
		t=s.charAt(s.length()-1)+t+s.charAt(0);
		return t;
	}
}
