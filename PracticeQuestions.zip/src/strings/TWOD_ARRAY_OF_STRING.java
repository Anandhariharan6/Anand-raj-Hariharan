package strings;

import java.util.Scanner;

public class TWOD_ARRAY_OF_STRING {
 static Scanner in = new Scanner(System.in);
	public static void main(String[] args)
	{
		System.out.println("enter col & rows of matrix");
		int n = in.nextInt();
		in.nextLine();
		String a[][] = new String[n][n];
		System.out.println("enter array elements:");
		for (int i = 0; i < a.length; i++)
		{
			for (int j = 0; j < a.length; j++) 
			{
				a[i][j] = in.nextLine();
			}
		}
	}
	private  static String s1( String a[][] ) 
	{
		for (int i = 0; i < a.length; i++) 
		{
			if()
		}
		return null;
	}
}
