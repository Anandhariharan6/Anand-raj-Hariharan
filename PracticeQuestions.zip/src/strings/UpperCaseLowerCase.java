package strings;

import java.util.Scanner;

public class UpperCaseLowerCase {
	public static String[] split(String str)
{
	int count=0;
	String word=" ";
	for (int i = 0; i < str.length(); i++)
	{
		if(str.charAt(i)==' ')
		{
			continue;
		}
		else
		{
			count++;
			while(i<str.length() && str.charAt(i)!=' ')
			{
				i++;
			}
		}
	}
	int k=0;
	String[] s=new String[count];
	for (int i = 0; i < str.length(); i++) 
	{
		if(str.charAt(i)==' ')
		{
			continue;
			}
		else
		{
			word="";
			while(i<str.length() && str.charAt(i)!=' ')
			{
				word=word+str.charAt(i);
				i++;
			}s[k++]=word;
		}
	}
	return s;
}

	static Scanner in = new Scanner(System.in);
	public static void main(String[] args) 
	{
		System.out.println("enter a string");
		String str=in.nextLine();
		String[] s=split(str);
		 String res="";
		for(int i=0;i<s.length;i++)
		{     res="";
			for(int j=0;j<s[i].length();j++)
			{
				if(j%2==0 && s[i].charAt(j)>'A' && s[i].charAt(j)<'Z')
				{
					int as=s[i].charAt(j);
					as+=32;   //as=as-32;
					char ch=(char)as;
					res+=ch;
				}
				else
				{
					res+=s[i].charAt(j);
				}
				
				
			}
			System.out.print(res);
			System.out.print(" ");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
