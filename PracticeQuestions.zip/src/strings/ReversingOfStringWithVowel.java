package strings;

import java.util.Scanner;

public class ReversingOfStringWithVowel
{

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter a String");
		String s= in.nextLine();
		//split Function
		int count=0;
		for (int i = 0; i < s.length(); i++)
		{
			if(s.charAt(i)==' ')
			{
				count++;
			}
		}
		String [] str = new String[count+1];
		int k=0;
		String s1="";
		for (int i = 0; i < s.length(); i++) 
		{
			if(s.charAt(i)==' ')
			{
				str[k]=s1;
				s1="";
				k++;
			}
			else
			{
				s1=s1+s.charAt(i);
			}
		}
		str[k]=s1;
		
		String vowels="";
		String consonents="";
		String rev ="";
//		String str="";
		char c=0;
//		for (int i=0;i < str.length; i++)
//		{
//			if((s.charAt(i)!=' ') &&( s.charAt(i)!='\0'))
//			{
//				sub=sub+s.charAt(i);
//			}
//		}	
		for (int i = 0; i < str.length; i++)
		{
			if(str[i].charAt(i)=='a' ||str[i].charAt(i)== 'e' || str[i].charAt(i)=='i' || str[i].charAt(i)=='o' || str[i].charAt(i)=='u' 
					 || str[i].charAt(i)=='A' ||str[i].charAt(i)== 'E' || str[i].charAt(i)=='I' || str[i].charAt(i)=='O' || str[i].charAt(i)=='U' )
			{
				for (int j =0 ; j < str[i].length(); j++) 
				{
					rev=str[i].charAt(j)+rev;
				}
			}
			else 
			{
				//c=(char)(str[i].charAt(i)+1);
				c=str[i].charAt(i);
				char b=(char)(c+1);
				consonents=consonents+c;
			}
		}
		System.out.println(rev+"  "+consonents);

	}
}
