package strings;

import java.util.Scanner;

public class reversing_the_string_in_same_place {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in = new Scanner(System.in);
		System.out.println("enter a string:");
		String s=in.nextLine();
		String rev="";
		for (int i = 0; i < s.length(); i++) 
		{
			rev=s.charAt(i)+rev;
		}
		System.out.println(rev);
	}

public static String[] split(String str)
{
	int count=0;
	String word=" ";
	for (int i = 0; i < str.length(); i++)
	{
		if(str.charAt(i)==' ')
		{
			continue;
		}
		else
		{
			count++;
			while(i<str.length() && str.charAt(i)!=' ')
			{
				i++;
			}
		}
	}
	int k=0;
	String[] s=new String[count];
	for (int i = 0; i < str.length(); i++) 
	{
		if(str.charAt(i)==' ')
		{
			continue;
			}
		else
		{
			word="";
			while(i<str.length() && str.charAt(i)!=' ')
			{
				word=word+str.charAt(i);
				i++;
			}s[k++]=word;
		}
	}
	return s;
}
}