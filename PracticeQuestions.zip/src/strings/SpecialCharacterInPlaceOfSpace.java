package strings;

import java.util.Scanner;

public class SpecialCharacterInPlaceOfSpace 
{
	public static String SpecialChar(String str)
	{
		String s= "";
		char c=0;
		for (int i = 0; i < str.length(); i++) 
		{
			if(str.charAt(i)==' ')
			{
				s=s+'@';
			}
			else
			{
				s=s+str.charAt(i);
			}
		}
		return s;
	}

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter a string ");
		String str = in.nextLine();
		String res = SpecialChar(str);
		System.out.println(res);
	}

}
