package strings;

import java.util.Scanner;

public class SpecialCharacter 
{
	static Scanner in = new Scanner(System.in);
	
	public static String special(String s)
	{
		String str ="";
		for (int i = 0; i < s.length(); i++)
		{
			if((s.charAt(i)==32) || 
					(s.charAt(i)>=65) && (s.charAt(i)<=90) || 
					(s.charAt(i)>=97) && (s.charAt(i)<=122) || 
					(s.charAt(i)>=48) && (s.charAt(i)<=57) )
			{
				str=str+s.charAt(i);
			}
			else
			{
				str=str+'&';
			}
		}
		return str;
	}
	public static void main(String[] args) 
	{
		System.out.println("enter a string");
		String s= in.nextLine();
		System.out.println(special(s));
	}
}
