package strings;

import java.util.Scanner;

public class REVERSING {
	static Scanner in = new Scanner(System.in);

	public static void main(String[] args)
	{
		System.out.println("enter a string: ");
		String n= in.nextLine();
		String rev="";
		for (int i = 0; i < n.length(); i++) 
		{
			if(n.charAt(i)==' ')
			{
				rev=rev+n.charAt(i);
			}
		}
		System.out.println(rev);
	}

}
