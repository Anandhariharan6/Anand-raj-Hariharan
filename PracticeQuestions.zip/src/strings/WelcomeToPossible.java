package strings;

import java.util.Scanner;

public class WelcomeToPossible 
{
	static Scanner in = new Scanner(System.in);
	
	public static void main(String[] args) 
	{
		System.out.println("enter a String :");
		String Str = in.nextLine();
		String s []=split(Str);
		String res="";
		for (int i = 0; i < s.length; i++) 
		{
			if(s.charAt(i)=='')
			{
				
			}
		}
		
		
	}

	
	
	
	
	public static String[] split(String str) 
	{
		int count = 0;
		String word = " ";
		for (int i = 0; i < str.length(); i++) 
		{
			if (str.charAt(i) == ' ')
			{
				continue;
			} else
			{
				count++;
				while (i < str.length() && str.charAt(i) != ' ')
				{
					i++;
				}
			}
		}
		int k = 0;
		String[] s = new String[count];
		for (int i = 0; i < str.length(); i++) 
		{
			if (str.charAt(i) == ' ') 
			{
				continue;
			} else {
				word = "";
				while (i < str.length() && str.charAt(i) != ' ') 
				{
					word = word + str.charAt(i);
					i++;
				}
				s[k++] = word;
			}
		}
		return s;
	}

}
