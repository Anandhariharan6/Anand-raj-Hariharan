package patterns;

import java.util.Scanner;

public class CheckingTheRange {
	public static void Check(int a,int b,int c)
	{
		if(a>=0 && a<=50) 
		{
			System.out.println("the numbers are in range");
		}
		if(b>=0 && b<=50)
		{
			System.out.println("the numbers are in range");
		}
		if(c>=0 && c<=50)
		{
			System.out.println("the numbers are in range");
		}
		else
		{
			System.out.println("the numbers are not in range");
		}
	}
	public static void even(int a,int b,int c)
	{
		int sum = 0;
		if(a>=0&&a<=50)  
			{
				if(a%2==0)
				{
					sum=sum+a;
				}
				 
		if(b>=0&&b<=50)
			{
				if(b%2==0)
				{
					sum=sum+b;
				}
			}
		 
		if(c>=0&&c<=50)
			{
				if(c%2==0)
				{
					sum=sum+c;
				}
			}
		System.out.println(sum);
	}
	}
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter first number");
		int a = in.nextInt();
		System.out.println("enter second number");
		int b = in.nextInt();
		System.out.println("enter third number");
		int c = in.nextInt();
		Check(a, b, c);
		even(a,b,c);
	}

}


