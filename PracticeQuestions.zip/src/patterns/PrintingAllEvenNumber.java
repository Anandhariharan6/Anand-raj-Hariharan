package patterns;

import java.util.Scanner;

public class PrintingAllEvenNumber 
{
	public static void Even()
	{
		for(int i=0;i<=100;i++)
		{
			if(i%2==0)
			{
				System.out.println(i);
			}
		}
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Even();

	}

}
