package patterns;

import java.util.Scanner;

public class PrintAllEvenNumbers {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter the number");
		int num = in.nextInt();
		for (int i = 1; i <= num; i++) 
		{
			if(i%2==0)
			{
				System.out.println("the even numbers are :"+i);
			}
		}

	}

}
