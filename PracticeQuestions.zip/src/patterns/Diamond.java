package patterns;

import java.util.Scanner;

public class Diamond {
	public static void diamond(int d)
	{
		for (int i = 0; i <= d; i++)
		{
			for (int j = 0; j <= d; j++) 
			{
				if(i+j>=d-1 && i>=j)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println();
		}
		for (int i = 0; i <= d; i++)
		{
			for (int j = 0; j <= d; j++) 
			{
				if(i+j<=d-1 && j>=i)
				{
					System.out.print("*");
				}
				else
				{
					System.out.print(" ");
				}
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter a number");
		int d = in.nextInt();
		diamond(d);

	}

}
