package patterns;

import java.util.Scanner;

public class Printing1 
{
	public static void pattern1(int n) 
	{
		for (int i = 1; i <= n; i++) 
		{
			for (int j = 1; j <= n+1; j++)
			{
					System.out.print("1");	
			}
			System.out.println();
		}
	}
	public static void pattern2(int n) 
	{
		for (int i = 1; i <= n; i++) 
		{
			for (int j = 1; j <= n+1; j++)
			{
				if(i%2==0)
					System.out.print("0");
				else
					System.out.print("1");
			}
			System.out.println();
		}
	}
	public static void pattern3(int n) 
	{
		for (int i = 1; i <= n; i++) 
		{
			for (int j = 1; j <= n+1; j++)
			{
				if(j%2==0)
					System.out.print("0");
				else
					System.out.print("1");
			}
			System.out.println();
		}
	}
	public static void pattern4(int n) 
	{
		for (int i = 1; i <= n; i++) 
		{
			for (int j = 1; j <= n; j++)
			{
				if(i==j)
					System.out.print("0");
				else
					System.out.print("1");
			}
			System.out.println();
		}
	}
	public static void pattern5(int n) 
	{
		for (int i = 1; i <= n; i++) 
		{
			for (int j = 1; j <= n; j++)
			{
				if(i<j)
					System.out.print("0");
				else
					System.out.print("1");
			}
			System.out.println();
		}
	}
	public static void pattern6(int n) 
	{
		for (int i = 1; i <= n; i++) 
		{
			for (int j = 1; j <= n; j++)
			{
				if(i>j)
					System.out.print("0");
				else
					System.out.print("1");
			}
			System.out.println();
		}
	}
	public static void pattern7(int n) 
	{
		for (int i = 1; i <= n; i++) 
		{
			for (int j = 1; j <= n; j++)
			{
				if(i<j)
					System.out.print("0");
				else
					System.out.print("1");
			}
			System.out.println();
		}
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter");
		int n = in.nextInt();
		pattern1(n);
		System.out.println();
		pattern2(n);
		System.out.println();
		pattern3(n);
		System.out.println();
		pattern4(n);
		System.out.println();
		pattern5(n);
		System.out.println();
		pattern6(n);
		System.out.println();
		pattern7(n);

	}

}
