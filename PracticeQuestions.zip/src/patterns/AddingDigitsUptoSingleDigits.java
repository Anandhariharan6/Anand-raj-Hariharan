package patterns;

import java.util.Scanner;

public class AddingDigitsUptoSingleDigits 
{
	public static void digit(int n)
	{
		int sum=0,rem,r1 = 0,r2 = 0;
		while(n!=0) 
		{
		rem=n%10;
		r1=r1+rem;
		n=n/10;
		}
		while(r1!=0)
		{
		r2=r1%10;
		sum=sum+r2;
		r1=r1/10;
		}
		System.out.println(sum);
	}
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter a number");
		int n= in.nextInt();
		digit(n);
	}

}
