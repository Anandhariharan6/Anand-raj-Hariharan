package codingchallange;

import java.util.Scanner;

public class convertingOneDtoTwoD 
{
	static Scanner in = new Scanner(System.in);
	static int row;
	static int col;
	static int res[]= new int[row];
	static int result[][]= new int[row][col];
	public static void main(String[] args)
	{
		System.out.println("enter no of rows");
		 row= in.nextInt();
		System.out.println("enter no of col");
		 col = in.nextInt();
		int a[][]= new int[row][col];
		System.out.println("enter for array a:");
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++)
			{
				a[i][j]=in.nextInt();
			}
		}
		boolean flag = true;
		while(flag)
		{
			System.out.println("Convert 2 d to 1 d");
			System.out.println("Convert 1 d to 2 d");
			int choice = in .nextInt();
			switch(choice)
			{
			case 1:res = con1(a);
			for (int i = 0; i < res.length; i++) 
			{
				System.out.print(res[i]);
			}
			System.out.println();
			break;
			case 2:result=con2(res,row,col);
			for (int i = 0; i < result.length; i++) 
			{
				for (int j = 0; j < result.length; j++)
				{
					System.out.print(result[i][j]);
				}
				System.out.println();
			}
			
			break;
			default:
				flag=false;
				System.out.println("invalid input");
			}
		}
	}

	public static int[] con1(int a[][]) 
	{
		int k=0;
		int index=0;
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++)
			{
				k++;
			}
		}
		int c2[]=new int[k];
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < a.length; j++) 
			{
				c2[index++]=a[i][j];
			}
		}
		return c2;
	}

	public static int[][] con2(int res[],int row,int col) 
	{
		int r2[][]= new int[row][col];
		int index=0;
		for (int i = 0; i < r2.length; i++) 
		{
			for (int j = 0; j < r2.length; j++) 
			{
				r2[i][j]=res[index++];
			}
		}
			System.out.println();
		return r2;	
	}
	
}
