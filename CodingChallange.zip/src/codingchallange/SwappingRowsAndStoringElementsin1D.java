package codingchallange;

import java.util.Scanner;

public class SwappingRowsAndStoringElementsin1D {
	static Scanner in = new Scanner(System.in);
	static int n;
	static int a1[][];
	static int swapped[][];
	static int res[];
	//static int even[];
	public static void main(String[] args)
	{
		System.out.println("enter the rows and col you want in the array");
		 n = in.nextInt();
		 System.out.println("enter the elements of array");
		 a1=new int[n][n];
		 for (int i = 0; i < n; i++)
		 {
			for (int j = 0; j < n; j++) 
			{
				a1[i][j]=in.nextInt();
			}
		}
		 boolean flag = true;
		 do {
			 System.out.println("1: Swapping first and last row of matrix");
			 System.out.println("2: Taking all even elements and storing in 1 d array");
			 int choice=in.nextInt();
			 switch(choice) 
			 {
			 case 1:swapped=swapping(a1);
			 for (int i = 0; i < a1.length; i++)
			 {
				for (int j = 0; j < a1.length; j++)
				{
					System.out.print(a1[i][j]+" ");
				}
				System.out.println();
			}
			 break;
			 case 2:res=even(swapped);
			 for (int i = 0; i < res.length; i++) 
			 {
					 System.out.print(res[i]+" ");
			}
			 System.out.println();
			 break;
			 default:
			 flag=false;
			 System.out.println("invalid input");
			 break;
			 }
		 }while(flag);
		 
		 
	}
	public static int[][] swapping(int a1[][])
	{
		for (int i = 0; i < a1.length; i++) 
		{
			for (int j = 0; j < a1.length; j++) 
			{
				if(i==0 || i==n-1) 
				{
					int temp=a1[i][j];
					a1[i][j]=a1[n-1][j];
					a1[n-1][j]=temp;
				}
			}
			System.out.println();
		}
		return a1;
	}
	
	public static int[] even(int swapped[][])
	{
		int index=0;
		int k=0;
		
		for (int i = 0; i < swapped.length; i++)
		{
			for (int j = 0; j < swapped.length; j++)
			{
				 if((swapped[i][j])%2==0)
				 {
				  k++;
				}
			}
		}
		int arr[]= new int[k];
		for (int i = 0; i < swapped.length; i++)
		{
			for (int j = 0; j < swapped.length; j++) 
			{
				if((swapped[i][j])%2==0)
				arr[index++]=swapped[i][j];
			}
		}
		return arr;
	}
//	public static int[] conversion(int res[][])
//	{
//		int k=0;
//		int index=0;
//		for (int i = 0; i < res.length; i++) 
//		{
//			for (int j = 0; j < res.length; j++)
//			{
//				k++;
//			}
//		}
//		int con[] = new int [n];
//		for (int i = 0; i < res.length; i++) 
//		{
//			for (int j = 0; j < res.length; j++) 
//			{
//				con[index++]=res[i][j];
//			}
//		}
//				
//		return con;
//	}
	}

