package codingchallange;

import java.util.Scanner;

public class challange3rdfeb
{
	static Scanner in = new Scanner(System.in);
	
	public static void main(String[] args)
	{
		System.out.println("enter the elements you wan in array 1");
		int n=in.nextInt();
		System.out.println("enter array elements");
		int a1[][]=new int[n][n];
		for (int i = 0; i < a1.length; i++) 
		{
			for (int j = 0; j < a1.length; j++) 
			{
				a1[i][j]= in.nextInt();
			}
		}
		System.out.println("enter the elements you want in array 2");
		int m=in.nextInt();
		System.out.println("enter array elements");
		int a2[][]=new int[m][m];
		for (int i = 0; i < a2.length; i++) 
		{
			for (int j = 0; j < a2.length; j++) 
			{
				a2[i][j]=in.nextInt();
			}
		}
		boolean flag = true;
		do
		{
			System.out.println("replace the left diagonal of the two 2_D matrix");
			System.out.println("Adding both the matrix and store it in 1 d array");
			System.out.println("");
			int choice=in.nextInt();
			switch(choice)
			{
			case 1:
			}
		}
	}
	public static int[][]
}
