package codingchallange;

import java.util.Scanner;

public class TwodArrayMenu {
	static Scanner in = new Scanner(System.in);
	static int r3[];
	static int insertion[];
	static int search[];
	static int back[][];
	public static void main(String[] args) {
		System.out.println("enter the no. of elements:");
		int n = in.nextInt();
		int mat[][] = new int[n][n];
		for (int i = 0; i < mat.length; i++)
		{
			for (int j = 0; j < mat.length; j++) 
			{
				mat[i][j]=in.nextInt();
			}
		}

		boolean flag = true;
		do {
			System.out.println("-----Menu-----");
			System.out.println("1: Swapping the row");
			System.out.println("2:swapping the coloum");
			System.out.println("3:converting to 1 d array");
			System.out.println("4:Insertion sort in 1 d array");
			System.out.println("5:Binary search in the sorted array");
			System.out.println("6:converting the 1 d array to 2 d array");
			System.out.println("ENTER YOUR CHOICE");
			int c = in.nextInt();
			switch (c) {
			case 1: {
				int mat1[][]= new int[mat.length][mat.length];
				for (int i = 0; i < mat.length; i++)
				{
					for (int j = 0; j < mat.length; j++)
					{
						mat1[i][j]=mat[i][j];
					}
				}
				int r1[][]=swappingrow(mat1);
				for (int i = 0; i < r1.length; i++)
				{
					for (int j = 0; j < r1.length; j++)
					{
						System.out.print(r1[i][j]+" ");
					}
					System.out.println();
				}
			}
				break;
			case 2: {
				int mat1[][]= new int[mat.length][mat.length];
				for (int i = 0; i < mat.length; i++)
				{
					for (int j = 0; j < mat.length; j++)
					{
						mat1[i][j]=mat[i][j];
					}
				}
				int r2[][]=swappingcol(mat1);
				for (int i = 0; i < r2.length; i++) 
				{
					for (int j = 0; j < r2.length; j++) 
					{
						System.out.print(r2[i][j]+" ");
					}
					System.out.println();
				}
				
			}
				break;
			case 3: {
				
				 r3=conversion(mat);
				for (int i = 0; i < r3.length; i++)
				{
					System.out.print(r3[i]+" ");
				}
				System.out.println();
			}
				break;
			case 4: {
				insertion=insertionsort(r3);
				for (int i = 0; i < insertion.length; i++)
				{
					System.out.print(insertion[i]+" ");
				}
				System.out.println();
			}
				break;
			case 5: {
				 int result =binarysearch(insertion);
				 if(result>0)
				 {
					 System.out.println("Element found at"+ result);
				 }
				 else
				 {
					 System.out.println("Element not found");
				 }
				
			}
				break;
			case 6: {
				back=convertingback(r3,n);
				for (int i = 0; i < back.length; i++) 
				{
					for (int j = 0; j < back.length; j++)
					{
						System.out.print(back[i][j]+" ");
					}
					System.out.println();
				}
			}
				break;
			case 7: {
				flag = false;
			}
			default:
				System.out.println("invalid input");

				break;
			}

		} while (flag);
	}



	private static int[][] convertingback(int[] r32, int n) {
		int res[][]= new int [n][n];
		int index=0;
		for (int i = 0; i < res.length; i++) 
		{
			for (int j = 0; j < res.length; j++) 
			{
				res[i][j]=r32[index++];
			}
		}
		return res;
	}



	private static int binarysearch(int[] insertion2) 
	{
		{
			int flag=0,pos=0,low=0,mid;
			int high = r3.length-1;
			System.out.println("enter key");
			int key = in.nextInt();
			while(low<=high)
			{
				mid=(low+high)/2;
				if(key == r3[mid])
				{
					pos=mid;
					flag=1;
					break;
				}
				else if(key>r3[mid])
				{
					low=mid+1;
				}
				else
				{
					high=mid-1;
				}
			}
			if(flag==1)
			{
				return pos+1;
			}
			else
			{
				return -1;
			}
		}	
	}
	private static int[] insertionsort(int r3[]) {
		for (int j = 1; j < r3.length; j++) 
		{
			int i=j-1;
			int key= r3[j];
			while (i>-1 && r3[i]>key)
			{
				r3[i+1]=r3[i];
				i--;
			}
			r3[i+1]=key;
		}
		return r3;
	}

	private static int[] conversion(int[][] mat) 
	{
//		int k=0;
//		
//		for (int i = 0; i < mat.length; i++) 
//		{
//			for (int j = 0; j < mat.length; j++) 
//			{
//				k++;
//			}
//		}
		int one[]= new int [mat.length*mat.length];
		int index=0;
		for (int i = 0; i < mat.length; i++) 
		{
			for (int j = 0; j < mat.length; j++)
			{
				one[index++]=mat[i][j];
			}
		}
		return one;
	}

	private static int[][] swappingcol(int[][] mat)
	{
		for (int i = 0; i < mat.length; i++) 
		{
			for (int j = 0; j < mat.length; j++)
			{
				if(j==0)
				{
					int temp=mat[i][j];
					mat[i][j]=mat[i][mat.length-2];
					mat[i][mat.length-2]=temp;
				}
			}
		}
		return mat;
	}

	private static int[][] swappingrow(int[][] mat1) 
	{
		for (int i = 0; i < mat1.length; i++) 
		{
			for (int j = 0; j < mat1.length; j++)
			{
				if(i==0)
				{
					int temp=mat1[i][j];
					mat1[i][j]=mat1[mat1.length-2][j];
					mat1[mat1.length-2][j]=temp;
				}
			}
		}
		return mat1;
	}

}
