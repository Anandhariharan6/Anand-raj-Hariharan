package codingchallange;
import java.util.Scanner;
public class DiagonalsSwapping {
	static Scanner in = new Scanner(System.in);
	public static void main(String[] args) {
		System.out.println("enter a:");
		int a =in.nextInt();
		System.out.println("enter b:");
		int b = in.nextInt();
		int x[][] = new int[a][b];
		System.out.println("enter data in x array");
		for (int i = 0; i < a; i++)
		{
			for (int j = 0; j < b; j++)
			{
				x[i][j]= in.nextInt();
			}
		}
		System.out.println("enter p:");
		int p =in.nextInt();
		System.out.println("enter r:");
		int r = in.nextInt();
		int d1[] = new int[a];
		int d2[] = new int[p];
		int y[][] = new int[p][r];
		System.out.println("enter data in y array");
		for (int i = 0; i < p; i++)
		{
			for (int j = 0; j < r; j++)
			{
				y[i][j]=in.nextInt();
			}
		}
		
		for (int i = 0; i < x.length; i++)
		{
			for (int j = 0; j < x[i].length; j++)
			{
				if(i+j==a-1)// left diagonal for x
				{
					d1[i]=x[i][j];
				}
			}
		}
		for (int i = 0; i < x.length; i++)
			{
				System.out.print(d1[i]);
			}
			System.out.println();
			
		for (int i = 0; i < y.length; i++)
		{
			for (int j = 0; j < y[i].length; j++)
			{
				if(i+j==p-1)//left diagonal for y
				{
					d2[i]=y[i][j];
				}
			}
		}
		
		for (int i = 0; i < y.length; i++) 
			{
				System.out.print(d2[i]);
			}
			System.out.println();
			
		for (int i = 0; i < y.length; i++) 
		{
			for (int j = 0; j < y[i].length; j++)
			{
				if(i+j==a-1)
				{
					x[i][j]=d2[i];//Swapping diagonal of y with x
				}
			}
		}
		
		for (int i = 0; i < y.length; i++) 
		{
			for (int j = 0; j < y[i].length; j++)
			{
				System.out.print(x[i][j]+" ");
			}
			System.out.println();
		}
		
		for (int i = 0; i < x.length; i++) 
		{
			for (int j = 0; j < x[i].length; j++)
			{
				if(i+j==a-1)
				{
					y[i][j]=d1[i];// Swapping diagonal of x with y
				}
				System.out.println();
			}
		}
		for (int i = 0; i < y.length; i++) 
		{
			for (int j = 0; j < y[i].length; j++)
			{
				System.out.print(y[i][j]+" ");
			}
			System.out.println();
		}
	}
}