package codingchallange;


import java.util.Scanner;


public class SwappingElementsWithoutDiagonal {
	static Scanner in = new Scanner(System.in);
	static int r1[][];
	public static void main(String[] args)
	{
		System.out.println("enter the size of array 1:");
		int n=in.nextInt();
		int x[][]= new int[n][n];
		for (int i = 0; i < x.length; i++) 
		{
			for (int j = 0; j < x.length; j++) 
			{
				x[i][j]=in.nextInt();
			}
		}
		System.out.println("enter the size of array 2:");
		int m = in.nextInt();
		int y[][]= new int[m][m];
		for (int i = 0; i < y.length; i++) 
		{
			for (int j = 0; j < y.length; j++)
			{
				y[i][j]=in.nextInt();
			}
		}
		boolean flag = true;
		do {
			System.out.println(" menu ");
			System.out.println("1.swapping the elements of the 2 d array without diagonal");
			System.out.println("2.storing both the swapped diagonal in 1 d array");
			System.out.println("3.performing inseryion sort in that array");
			System.out.println("4.performing binary search in that sorted 1 d array");
			System.out.println("5.converting back to 2 d array");
			System.out.println("enter your choice");
			int c= in.nextInt();
			switch (c) {
			case 1:
			{
				int[][] x1=new int[n][n];
				for (int i = 0; i < x.length; i++) 
				{
					for (int j = 0; j < x.length; j++) 
					{
						
						x1[i][j]=x[i][j];
					}
				}
				int[][] y1=new int[n][n];
				for (int i = 0; i < x.length; i++) 
				{
					for (int j = 0; j < x.length; j++) 
					{
						y1[i][j]=y[i][j];
					}
				}
				r1=swapping(x1,y1);
				for (int i = 0; i < r1.length; i++) {
					for (int j = 0; j < r1.length; j++) {
						System.out.print(r1[i][j]+" ");
					}
					System.out.println();
				}
				int r2[][]=swapping(y, x);
				for (int i = 0; i < r1.length; i++) {
					for (int j = 0; j < r1.length; j++) {
						System.out.print(r2[i][j]+" ");
					}
					System.out.println();
				}
			}
			break;
			case 2:
			{
				//conversion();
			}
			break;
			case 3:
			{
				//insertionsort();
			}
			break;
			case 4:
			{
				//binsearch();
			}
			break;
			case 5:
			{
				//totwod();
			}
			break;
			case 6:
			{
				flag=false;
			}
			break;

			default:
				System.out.println("invalid input");
				break;
			}
			
		} while (flag);
	}
	private static int[][] swapping(int[][] x, int[][] y) {
		for (int i = 0; i < y.length; i++) 
		{
			for (int j = 0; j < y.length; j++) 
			{
				if(i!=j)
				{
					int temp=x[i][j];
					x[i][j]=y[i][j];
					y[i][j]=temp;
				}
			}
		}
		return x;
	}

}
