package codingchallange;

import java.util.Scanner;

public class Stringtest {
	static Scanner in = new Scanner(System.in);


	public static void main(String[] args) {
		System.out.println("enter the string:");
		String s = in.nextLine();
		boolean flag = true;
		do {
			System.out.println("menu");
			System.out.println("1. reverse and print the largest word");
			System.out.println("2. reverse and print the smallest word");
			System.out.println("enter your choice");
			int c = in.nextInt();
			switch (c) {
			case 1:
				String result = big(s);
				System.out.println(result);
				break;
			case 2:
				String small=smallest(s);
				System.out.println(small);
				break;
			default:
				break;
			}
		} while (flag);

	}

	private static String smallest(String s) {
		String word1 []=split(s);
		String str = word1[0];
		for (int i = 0; i < word1.length; i++)
		{
			if( str.length() > word1[i].length())
			{
				str=word1[i];
			}
		}
		System.out.println(str);
		String reversed=reverse1(str);
		return reversed;
	}

	private static String big(String s) {
		String words[] = split(s);
		String str=words[0];
		for (int i = 1; i < words.length-1; i++)
		{
			if(str.length() < words[i].length())
			{
				str=words[i];
			}
		}
		System.out.println(str);
		String reversed=reverse1(str);
		return reversed;
	}

	private static String reverse1(String str) {
		String reversed="";
		for (int i = str.length()-1; i >=0; i--) {
			reversed=reversed+str.charAt(i);
		}
		return reversed;
	}

	private static String[] split(String s) {
		// TODO Auto-generated method stub
		int c = 0;

		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == ' ') {
				c++;
			}
		}
		String a[] = new String[c + 1];
		String str = "";
		int k = 0;
		for (int i = 0; i < s.length(); i++) {
			if (s.charAt(i) == ' ') {
				a[k++] = str;
				str = "";
			} else {
				str = str + s.charAt(i);
			}
		}
		a[k++] = str;
		return a;
	}
}
