package codingchallange;

import java.util.Scanner;

public class SwitchCase {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		boolean flag = true;
		System.out.println("enter your name:");
		String name = sc.nextLine();
		System.out.println("enter your years of experience:");
		int year = sc.nextInt();
		do {
			
				switch (year) {
				case 1:
				{
					System.out.println("Congratulations "+name+ "You are eligible for the following:  ");
					System.out.println("Yor eligible for powerbank");
					break;
				}
				case 2:
				{
					System.out.println("Congratulations "+name+ "You are eligible for the following:  ");
					System.out.println("Yor eligible for powerbank");
					break;
				}
				case 3:
				{
					System.out.println("Congratulations "+name+ "You are eligible for the following:  ");
					System.out.println("Yor eligible for powerbank and a bluetooth speaker");
					break;
				}
				case 4:
				{
					System.out.println("Congratulations "+name+ "You are eligible for the following:  ");
					System.out.println("Yor eligible for powerbank and a bluetooth speaker");
					break;
				}
				case 5:
				{
					System.out.println("Congratulations "+name+ "You are eligible for the following:  ");
					System.out.println("Yor eligible for powerbank , a bluetooth speaker and a fitness band");
					break;
				}
				case 6:
				{
					System.out.println("Congratulations "+name+ "You are eligible for the following:  ");
					System.out.println("Yor eligible for powerbank , a bluetooth speaker and a fitness band");
					break;
				}
				case 7:
				{
					System.out.println("Congratulations "+name+ "You are eligible for the following:  ");
					System.out.println("laptop");
					break;
				}
				case 8:
				{
					System.out.println("Congratulations "+name+ "You are eligible for the following:  ");
					System.out.println("laptop");
					break;
				}
				default:
				{
					System.out.println("enter a valid input");
					break;
				}
			}
				System.out.println("Continue Y or N");
				char ch = sc.next().charAt(0);
				if(ch!='N')
				{
					System.out.println("enter your names:");
					sc.nextLine();
					String name1 = sc.nextLine();
					System.out.println("enter your years of experiences:");
					int year1 = sc.nextInt();
				}
				else
				{
					flag=false;
					System.out.println("qwertyuiop");
				}
				/*switch (ch) {
				case 'Y':
				{
					System.out.println("enter your names:");
					sc.nextLine();
					String name1 = sc.nextLine();
					System.out.println("enter your years of experiences:");
					int year1 = sc.nextInt();
					break;
				}
			case 'N': {
				flag = false;
				System.out.println();
			}
			}*/
		} while (flag);
	}
}
