package codingchallange;

import java.util.Scanner;

public class Challange1 {
	static Scanner sc = new Scanner(System.in);
	static String arr[][];
	static int row;
	static int col;

	public static void main(String[] args) {
		System.out.println("Enter the number of rows: ");
		row = sc.nextInt();
		System.out.println("Enter the number of columns: ");
		col = sc.nextInt();
		arr = new String[row][col];
		for (int i = 0; i < row; i++) 
		{
			for (int j = 0; j < col; j++) 
			{
				arr[i][j] = sc.next();
			}
		}
		boolean flag = true;
		do {
			System.out.println("\n1-uppercase and lowecase for even and odd position\n2-Form a sentence\n3-Exit\n");
			int choice = sc.nextInt();
			switch (choice) {

			case 1:
				String res = change(arr);
				System.out.println(res);
				break;

			case 2:
				sentence(arr);
				break;

			case 3:
				flag = false;
				break;

			default:
				System.out.println("Invalid choice");
				break;
			}
		} while (flag);
	}

	private static String change(String[][] arr2) 
	{
		System.out.println("Enter the ith position:");
		int first = sc.nextInt();
		System.out.println("Enter the jth position:");
		int second = sc.nextInt();
		String res = "";
		for (int i = 0; i < row; i++) 
		{
			for (int j = 0; j < col; j++) 
			{
				if (i == first && j == second) 
				{
					res = arr[i][j];
				}
			}
		}

		System.out.println(res);
		String res1 = "";
		for (int k = 0; k < res.length(); k++)
		{
			if (k % 2 == 0) 
			{
				char c = res.charAt(k);
				if (65 <= c && c <= 90)
				{
					c = (char) ((c + 32));
					res1 = res1 + c;
				} else 
				{
					res1 = res1 + c;
				}
			}
			else 
			{
				char c = res.charAt(k);
				if (97 <= c && c <= 122) 
				{
					c = (char) ((c - 32));
					res1 = res1 + c;
				} 
				else 
				{
					res1 = res1 + c;
				}
			}
		}
		return res1;
	}

	private static void sentence(String[][] arr2)
	{
		String[] arr1 = new String[5];
		int index = 0;
		for (int i = 0; i < row; i++) 
		{
			for (int j = 0; j < col; j++) 
			{
				if ((i + j) % 2 == 0) 
				{
					arr1[index] = arr[i][j];
					index++;
				}
			}
		}
		System.out.println(arr1[0] + " " + arr1[arr1.length - 2]);
	}
}
