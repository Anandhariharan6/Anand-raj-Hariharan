package codingchallange;

import java.util.Scanner;

public class String1 {
	static Scanner in= new Scanner(System.in);
	static String result[];
	static String res;
	public static void main(String[] args) 
	{
		System.out.println("enter a string:");
		String s= in.nextLine();
		result=split(s);
		 res=ccu(result);
	}
	private static String[] split(String s)
	{
		int c=0;
		for (int i = 0; i < s.length(); i++)
		{
			if(s.charAt(i)==' ')
			{
				c++;
			}
		}
		String arr[]= new String[c+1];
		String str="";
		int index=0;
		for (int i = 0; i < arr.length; i++)
		{
			if(s.charAt(i)==' ')
			{
				arr[index++]=str;
				str="";
			}
			else
			{
				str=str+s.charAt(i);
			}
		}
		arr[index++]=str;
		return arr;
	}
	private static String ccu(String[] result2)
	{
		String str="";
		for (int i = 0; i < result2.length; i++) 
		{
			str=str+result2[i].charAt(0);
			for(int j=1;j<result2[i+1].length()-1;j++)
			{
				str=str+result2[i+1].charAt(j);
			}
			str=str+result2[i].charAt(result2[i].length()-1);
			
		}
		return null;
	}
	

}
