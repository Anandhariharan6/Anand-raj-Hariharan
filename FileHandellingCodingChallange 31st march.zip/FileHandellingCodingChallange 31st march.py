# -*- coding: utf-8 -*-
"""
Created on Tue Mar 31 16:40:35 2020

@author: M1057669
"""

'''
Take a file with n number of rows and create 2 files with
 first half records in 1 file and second half in the other.
 Please make sure
 that both the output file have proper headers.
'''
f=open('C://Users//M1057669//.spyder-py3//CodingChallangeData.txt','r')
l1=f.readlines()
l2=l1[0:int(len(l1)/2)]
print(l2)
l3=l1[0:1]
l4=l1[int(len(l1)/2):int(len(l1))]
l5=l3+l4
print(l5)

n1=open('C://Users//M1057669//.spyder-py3//c1.txt','w')
n1.writelines(l2)
n1.close()

n2=open('C://Users//M1057669//.spyder-py3//c2.txt','w')
n2.writelines(l5)
n2.close()
#=================================================================
f=open('C://Users//M1057669//.spyder-py3//codingChallange2ndQuestion.txt','r')
l1=f.readlines()
l2=l1[0:int(len(l1))]
print(l2)
