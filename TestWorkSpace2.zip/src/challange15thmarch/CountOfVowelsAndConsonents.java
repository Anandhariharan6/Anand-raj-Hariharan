package challange15thmarch;

public class CountOfVowelsAndConsonents {

	public static void main(String[] args)
	{
		

	}

}
//count the no of alphabets in the second word and then display the sum of the 
//ASCII values of the vowels present in the second word