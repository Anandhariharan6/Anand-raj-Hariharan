package challange15thmarch;

import java.util.Scanner;

public class IncrementTheVowelsBy2 {
	
	static Scanner in = new Scanner(System.in);
	static int count;
	public static void main(String[] args) 
	{
		System.out.println("ENTER A STRING:");
		String str=in.nextLine();
		String []s= split(str);
		boolean flag=true;
		do {
			System.out.println("----MENU-----");
			System.out.println("1-COUNT THE NO. OF VOWELS. ");
			System.out.println("2-INCREASE THE VOWEL COUNT BY NO. OF VOWELS.");
			System.out.println("3-EXIT THE PROGRAM.");
			System.out.println("ENTER YOU CHOICE.");
			int c= in.nextInt();
			switch (c) {
			case 1:
			{
				 count=Count(s);
				System.out.println(count);
			}
				break;
			case 2:
			{
				String [] increment=ByTwo(s,count);
				for (int i = 0; i < increment.length; i++) 
				{
					System.out.print(increment[i]);
				}
				System.out.println();
			}
			break;
			case 3:
			{
				flag=false;
				System.out.println("PROGRAM EXIT");
			}
			break;
			default:
				System.out.println("ENTER VALID INPUTS.");
				break;
			}
		} while (flag);
		

	}
	
	private static String[] ByTwo(String[] s,int count) 
	{
		String[] p=new String[s.length];
		String p1="";
		int k=0;
		for (int i = 0; i < s.length; i++) 
		{
			for (int j = 0; j < s[i].length(); j++)
			{
				if(s[i].charAt(j)=='a' ||s[i].charAt(j)== 'e' || s[i].charAt(j)=='i' || s[i].charAt(j)=='o' || s[i].charAt(j)=='u' 
						 || s[i].charAt(j)=='A' ||s[i].charAt(j)== 'E' ||s[i].charAt(j)=='I' ||s[i].charAt(j)=='O' || s[i].charAt(j)=='U' )
				{
					int as=s[i].charAt(j);
				    as=as+count;
					char ch=(char)as;
					p1=p1+ch;
				}
				else
				{
					p1=p1+s[i].charAt(j);
				}
			}
			p[k++]=p1;
			p1=" ";
		}
		return p;
	}

	private static int Count(String[] s) 
	{
		int c=0;
		String vowels="";
		int vcount=0;
		for (int i = 0; i < s.length; i++)
		{
			for (int j = 0; j < s[i].length(); j++) 
			{
				if(s[i].charAt(j)=='a' ||s[i].charAt(j)== 'e' || s[i].charAt(j)=='i' || s[i].charAt(j)=='o' || s[i].charAt(j)=='u' 
					 || s[i].charAt(j)=='A' ||s[i].charAt(j)== 'E' ||s[i].charAt(j)=='I' ||s[i].charAt(j)=='O' || s[i].charAt(j)=='U' )
				{
					vowels=vowels+s[i].charAt(j);
					++vcount;
				}
			}
			c=vcount;
		}
		return c;
	}


	public static String[] split(String str)
	{
		int count=0;
		String word=" ";
		for (int i = 0; i < str.length(); i++)
		{
			if(str.charAt(i)==' ')
			{
				System.out.println(str.charAt(i));
			}
			else
			{
				count++;
				while(i<str.length() && str.charAt(i)!=' ')
				{
					i++;
				}
			}
		}
		int k=0;
		String[] s=new String[count];
		for (int i = 0; i < str.length(); i++) 
		{
			if(str.charAt(i)==' ')
			{
				System.out.println(str.charAt(i));
			}
			else
			{
				word="";
				while(i<str.length() && str.charAt(i)!=' ')
				{
					word=word+str.charAt(i);
					i++;
				}s[k++]=word;
			}
		}
		return s;
	}

}


