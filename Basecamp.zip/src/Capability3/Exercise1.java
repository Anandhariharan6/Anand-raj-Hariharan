package Capability3;

import java.util.Scanner;

//Bubble Sort
public class Exercise1 {
	public static void bubblesort(int a[])
	{
		for (int i = 0; i < a.length-1; i++)
		{
			for (int j = 0; j < a.length-i-1; j++) 
			{
				if(a[j]>a[j+1])
				{
					int temp = a[j];
					a[j] = a[j+1];
					a[j+1] = temp;
				}
			}
		}
		
	}

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter the size of the array");
		int size = in.nextInt();
		int a[] = new int[size];
		for (int i = 0; i < a.length; i++)
		{
			System.out.println("enter the elements ["+i+"]position"); 
			a[i]=in.nextInt();
		}
		bubblesort(a);
		for(int b:a)
			System.out.print(b);
	}

}
