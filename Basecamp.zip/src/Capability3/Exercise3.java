package Capability3;

public class Exercise3 {

}
