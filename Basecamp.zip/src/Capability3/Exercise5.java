package Capability3;

import java.util.Scanner;

public class Exercise5 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		int choice;
		while (true) {
			System.out.println("\n---Menu Driven---");
			System.out.println("Enter choice 1 for Bubble Sorting: ");
			System.out.println("Enter choice 2 for Insertion sorting: ");
			System.out.println("Enter choice 3 for Searching : ");
			System.out.println("Enter 4 to Exit. ");
			System.out.println("Enter your choice: ");
			choice = sc.nextInt();
			switch (choice) {
			case 1: {
				System.out.println("Enter range: ");
				int p = sc.nextInt();
				String[] a = new String[p];
				System.out.println("Enter names :");
				for (int i = 0; i < p; i++) {
					a[i] = sc.next();
				}
				String z[] = bubble(p, a);
				System.out.println("Sorted  array :");
				for (int i = 0; i < p; i++) {
					System.out.print(z[i] + " ");
				}
				break;
			}
			case 2: {
				System.out.println("Enter range: ");
				int p = sc.nextInt();
				String[] s = new String[p];
				System.out.println("Enter names :");
				for (int i = 0; i < p; i++) {
					s[i] = sc.next();
				}
				String z[] = insertion(s);
				System.out.println("Sorted  array :");
				for (int i = 0; i < p; i++) {
					System.out.print(z[i] + " ");
				}
				break;
			}
			case 3: {
				System.out.println("Enter range: ");
				int p = sc.nextInt();
				String[] s = new String[p];
				System.out.println("Enter names :");
				for (int i = 0; i < p; i++) {
					s[i] = sc.next();
				}
				s = sort(s);
				for (int i = 0; i < p; i++) {
					System.out.println(s[i]);
				}
				System.out.println("enter search string");
				String x = sc.next();
				boolean m = search(s, x);
				if (m == true) {
					System.out.println("True..");
				} else {
					System.out.println("False...");
				}
				// System.out.println(search(s, s.length - 1, x));
				break;
			}
			case 4: {
				System.exit(0);
				break;
			}
			default: {
				System.out.println("Wrong choice..!!! ");
			}
			}
		}
	}

	public static String[] bubble(int n, String a[]) {
		for (int i = 0; i < n - 1; i++) {
			for (int j = 0; j < n - 1 - i; j++) {
				if (a[j].compareTo(a[j + 1]) > 0) {
					String temp = a[j];
					a[j] = a[j + 1];
					a[j + 1] = temp;
				}
			}
		}
		return a;
	}

	public static String[] insertion(String a[]) {
		String temp = " ", k = " ";
		for (int i = 0; i < a.length; i++) {
			k = a[i];
			int j = i - 1;
			while (j >= 0 && a[j].compareTo(k) > 0) {
				temp = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp;
				j--;
			}
		}
		return a;
	}

	public static boolean search(String a[], String s) {
		return false;
		
	}

	public static String[] sort(String a[]) {
		int l = a.length;
		for (int i = 0; i < l - 1; i++) {
			for (int j = 0; j < l - i - 1; j++) {
				if (a[j].compareTo(a[j + 1]) > 0) {
					String temp = a[j];
					a[j] = a[j + 1];
					a[j + 1] = temp;
				}
			}
		}
		return a;
	}

}
