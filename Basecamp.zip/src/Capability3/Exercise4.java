package Capability3;

import java.util.Scanner;
//insertion Sort
public class Exercise4 {
	public static int[] insertionesort(int a[])
	{
		for (int i = 1; i < a.length; i++)
		{
			int key=a[i];
			int j=i-1;
			while(j>=0 && a[j]>key)
			{
				a[j+1]=a[j];
			}
			j--;
			a[j+1]=key;
		}
		return a;
		
	}

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter the size of the array");
		int size = in.nextInt();
		int a[] = new int[size];
		for (int i = 0; i < a.length; i++)
		{
			System.out.println("enter the elements ["+i+"]position"); 
			a[i]=in.nextInt();
		}
		int b[]=insertionesort(a);
		for (int i = 0; i < b.length; i++) 
		{
			System.out.print(b+" ");
		}
			
	}

}
