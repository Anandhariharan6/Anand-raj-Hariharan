package Capability3;

import java.util.Scanner;

public class Exercise2 {
	public static boolean linearSearch(int a[],int s)
	{
		for (int i = 0; i < a.length; i++) 
		{
			if(a[i]==s)
				return true;	
		}
		return false;
	}

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter the size of the array");
		int size = in.nextInt();
		int a[] = new int[size];
		for (int i = 0; i < a.length; i++)
		{
			System.out.println("enter the elements ["+i+"]position"); 
			a[i]=in.nextInt();
		}
		System.out.println("enter the search element");
		int s = in.nextInt();
		boolean res=linearSearch(a,s);
		if(res == true)
		{
			System.out.println(res);
		}
		else
		{
			System.out.println(res);
		}
	}

}
