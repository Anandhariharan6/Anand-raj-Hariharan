package Capability2;
//unique elements

import java.util.Scanner;

public class Exercise13 {

	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter the no of elements you want in array 1:");
		int a1 = in.nextInt();
		int a[] = new int[a1];
		System.out.println("enter the elements:");
		for (int i = 0; i < a.length; i++) {
			a[i] = in.nextInt();
		}
		System.out.println("enter the no of elements you want in array 2:");
		int a2 = in.nextInt();
		int b[] = new int[a2];
		System.out.println("enter the elements:");
		for (int i = 0; i < b.length; i++) {
			b[i] = in.nextInt();
		}
		int c=0;
		for (int i = 0; i < a.length; i++) 
		{
			for (int j = 0; j < b.length; j++)
			{
				if(a[i]==b[j])
				{
					c++;
				}
			}
			if(c==0)
				System.out.println(a[i]+" ");
		}
		for (int i = 0; i < b.length; i++)
		{
			for (int j = 0; j < a.length; j++) 
			{
				if(b[i]==a[j])
				{
					c++;
				}
			}
			if(c==0)
				System.out.println(b[i]+" ");
		}
		
	}
}
