package Capability2;

import java.util.Scanner;

public class Exercise10 {
	public static boolean length(String code) 
	{
		if (code.length() != 10) 
		{
			return false;
		}
		else
		{
			return firstchar(code);
		}
	}
	
	public static boolean firstchar(String code)
	{
		if (code.charAt(0)=='0'|| code.charAt(0)=='2')
			return true;
		else
		return secondthird(code) ;
	}
	
	public static boolean secondthird(String code)
	{
		if(code.charAt(1) >= 65 &&  code.charAt(1) <= 90 &&  code.charAt(2) >= 65 &&  code.charAt(2) <= 90)
			return true;
		else
			return digits1(code);
	}
	
	public static boolean digits1(String code)
	{
		if(code.charAt(3) >= 0 &&  code.charAt(3) <= 9 && code.charAt(4) >= 0 &&  code.charAt(4) <= 9)
			return true;
		else
			return combination(code);
	}
	
	public static boolean combination(String code)
	{
		if(code.charAt(5) == 'C' || code.charAt(5) == 'I' || code.charAt(5) == 'E' || code.charAt(5) == 'M' || code.charAt(5) == 'S')
			if(code.charAt(6) == 'C' || code.charAt(6) == 'I' || code.charAt(6) == 'E' || code.charAt(6) == 'M' || code.charAt(6) == 's')
			return true;
		else
			return digits2(code);
		return false;
	}
	
	public static boolean digits2(String code)
	{
		if(code.charAt(7) >= 0 &&  code.charAt(7) <= 9 && code.charAt(8) >= 0 &&  code.charAt(8) <= 9 && code.charAt(9) >= 0 &&  code.charAt(9) <= 9)
			return true;
		else
			return false;
	}
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("Enter USN ID :");
		String code = in.nextLine();
		boolean USN=length(code);
		if(USN==true)
			System.out.println("SUCCESS");
		else
			System.out.println("INVALID");
	}

}
