package Capability2;

import java.util.Scanner;

public class Exercise6 {
	public static void main(String[] args) {
		System.out.println("enter your name:");
		Scanner in = new Scanner(System.in);
		String name = in.nextLine();
		char c = name.charAt(0);
		String s=""+c;
		for (int i = 1; i <= name.length()-1; i++) 
		{
			if(name.charAt(i)==' ')
			{
				s=s+name.charAt(i+1);
			}
		}System.out.println(s);
	}

}
