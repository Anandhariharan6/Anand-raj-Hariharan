package Capability2;

import java.util.Scanner;

public class Exercise4 {
	public static int reverse(int n) {
		int rem = 0;
		int rev = 0;
		while (n > 0) {
			rem = n % 10;
			n = n / 10;
			rev = (rev * 10) + rem;
		}
		return rev;
	}

	public static void main(String[] args) {
		System.out.println("enter the inputs:");
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int rev=reverse(n);
		System.out.println(rev);

	}

}
