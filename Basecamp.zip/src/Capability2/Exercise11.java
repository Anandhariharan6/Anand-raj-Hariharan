package Capability2;

import java.util.Scanner;

public class Exercise11 
{
	public static String reverse(String n)
	{
		String rev="";
		String substr="";
		String res="";
		for (int i=0;i < n.length(); i++)
		{
			if((n.charAt(i)!=' ') &&( n.charAt(i)!='\0'))
			{
				substr=substr+n.charAt(i);
			}
			else
			{
				for (int j = 0; j < substr.length(); j++) 
				{
					if((substr.charAt(j)>='a' && substr.charAt(j)>='z' || substr.charAt(j)>='A' && substr.charAt(j)>='Z'))
					{
						rev = substr.charAt(j)+rev;
					}
					else
					{
						rev = rev + substr.charAt(j);
					}
				}
				res=res+rev+" ";
				rev="";
				substr="";
			}
		}
		return res;
	}

	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		System.out.println("Enter a String you want to reverse");
		String n = in .nextLine();
		n=n+"\0";
		String reverse=reverse(n);
		System.out.println("Reverse String is = "+reverse);
	}

}
