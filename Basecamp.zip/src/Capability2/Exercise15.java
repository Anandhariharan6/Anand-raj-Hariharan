package Capability2;

import java.util.Scanner;

public class Exercise15 {
	
	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter row: ");
		int a=in.nextInt();
		System.out.println("enter col: ");
		int b=in.nextInt();
		int x[][]= new int[a][b];
		for (int i = 0; i < a; i++)
		{
			for (int j = 0; j < b; j++) 
			{
				System.out.println("enter data in x["+i+" "+j+"]position");
				x[i][j]= in.nextInt();
			}
		}
		
		int y[][]=new int[a][b];
		for (int i = 0; i < a; i++) 
		{
			for (int j = 0; j < b; j++)
			{
				System.out.println("enter data in y["+i+" "+j+"]position");
				y[i][j]= in.nextInt();
			}
		}
		
		int sum[][]=new int[b][a];
		for (int i = 0; i < b; i++) 
		{
			for (int k = 0; k < a; k++)
			{
				 sum[i][k]=x[i][k]+y[i][k];
			}
			
		}
		System.out.println("sum of elements of array are: ");
		for (int i = 0; i < a; i++)
		{
			for (int j = 0; j < b; j++) 
			{
				System.out.print(sum[i][j]+" ");
			}
		}
		System.out.println();
		
	}

}
