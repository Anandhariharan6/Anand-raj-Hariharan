package Capability2;

import java.util.Scanner;

//sum of elements of an array
public class Exercise1 {
	static Scanner in = new Scanner(System.in);
	public static int sumOfArrayElement(int[] a,int length)
	{
		int sum=0;
		for (int i = 0; i < a.length; i++)
		{
			sum=sum+a[i];
			a[i]=in.nextInt();
		}
		return sum;
	}
	public static void main(String[] args) 
	{
		System.out.println("enter the length of array");
		int length=in.nextInt();
		int a[]=new int[length];
		System.out.println("enter the elements of the array");
		int sum=sumOfArrayElement(a,length);
		System.out.println("sum of elements of an array is: "+sum);
	}

}
