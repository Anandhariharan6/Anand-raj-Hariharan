package Capability2;

import java.util.Scanner;

public class Exercise12 
{
	public static void check(String s)
	{
		String s1="";
		for (int i = 0; i < s.length(); i++)
		{
			char c = s.charAt(i);
			if(c>='A' && c<='Z')
			{
				c=(char)(c+32);
				s1=s1+c;
			}
			else
			{
				s1=s1+c;
			}
		}
		for(int i=0;i<s1.length();i++)
		{
		int count=1;
		while(i< s1.length()-1 && s1.charAt(i)== s1.charAt(i+1))
		{
		count++;
		i++;
		}
		System.out.print(s1.charAt(i));
		System.out.print(count);
		}
		
	}
	public static void main(String[] args) {
		
		Scanner in = new Scanner(System.in);
		System.out.println("enter string");
		String s = in.nextLine();
		check(s);
		}
}
