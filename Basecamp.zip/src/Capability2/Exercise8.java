package Capability2;

import java.util.Scanner;

public class Exercise8 {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter first name");
		String s1=in.nextLine();
		System.out.println("enter second name");
		String s2 = in.nextLine();
		String s3="";
		String s4="";
		String s5="";
		String s6="";
		String s7="";
		String s8="";
		int i=0;
		int j=0;
		while(s1.charAt(i)!=' ')
		{
			char c=s1.charAt(i);
			s3=s3+c;
			i++;
		}
		while(s2.charAt(j)!=' ')
		{
			char c=s2.charAt(j);
			s4=s4+c;
			j++;
		}
		for(int a=s1.indexOf(' ');a<s1.length();a++)
		{
			char c=s1.charAt(a);
			s5=s5+c;
		}
		for(int b=s2.indexOf(' ');b<s2.length();b++)
		{
			char c=s2.charAt(b);
			s6=s6+c;
		}
		s7=s3+s6;
		s8=s4+s5;
		System.out.println(s7);
		System.out.println(s8);
	}

}
