package Capability2;
//Handling multiple array
import java.util.Scanner;

public class Exercise2 {
	public static void main(String[] args) {
		int n, m, c, i;
		Scanner in = new Scanner(System.in);
		System.out.println("Enter the no of elements you want for 1st array");
		n = in.nextInt();
		System.out.println("Enter the no of elements for want for 2nd array");
		m = in.nextInt();
		double[] ar1 = new double[n];
		double[] ar2 = new double[m];
		if(n<m)
		{
			 c=m;
		}
		else
		{
			 c=n;
		}
		
		int result[] = new int[c];
		System.out.println("Enter elements of 1st array");
		for (i = 0; i < n; i++)
		{
			ar1[i] = in.nextDouble();
		}
		System.out.println("Enter elements of 2nd array");
		for (i = 0; i < m; i++)
		{
			ar2[i] = in.nextDouble();
		}
		for (int k = 0; k < c; k++)
		{
			result[k] = (int) (ar1[k] + ar2[k]);
		}
		for (i = 0; i < c; i++)
		{
		System.out.print(result[i]+ " ");
		}
	}
}
