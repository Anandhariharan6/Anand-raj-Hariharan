package Capability2;

import java.util.Scanner;

public class Exercise17 {
	static int rd=0,rowsum=0,colsum=0,ld=0;
	public static void isMagic(int x[][],int a)
	{
		for (int i = 0; i < x.length; i++)
		{
			for (int j = 0; j < x[i].length; j++) 
			{
				if(i==j)
				rd=rd+x[i][j];
			}
			System.out.println();
		}
		System.out.println(rd);
		
		for (int i = 0; i < x.length; i++) 
		{
			for (int j = 0; j < x[i].length; j++) 
			{
				if(i+j==a-1)
				{
					ld=ld+x[i][j];
				}
			}
			System.out.println();
		}
		System.out.println(ld);
		
		for (int i = 0; i < x.length; i++) 
		{
			for (int j = 0; j < x[i].length; j++) 
			{
				rowsum=rowsum+x[i][j];
			}
			System.out.println();
		}
		System.out.println(rowsum);
		
		for (int i = 0; i < x.length; i++) 
		{
			for (int j = 0; j < x[i].length; j++) 
			{
				colsum=colsum+x[i][j];
			}
			System.out.println();
		}
		System.out.println(colsum);
		if(rowsum==colsum || ld==rd)
		{
			System.out.println("magic array");
		}
		else
		{
			System.out.println("not magic array");
		}
	}
	
	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter a:");
		int a =in.nextInt();
		System.out.println("enter b:");
		int b = in.nextInt();
		int x[][] = new int[a][b];
		for (int i = 0; i < x.length; i++)
		{
			for (int j = 0; j < x[i].length; j++)
			{
				System.out.println("enter data in x["+i+" "+j+"]position");
				x[i][j]= in.nextInt();
			}
		}
		
		isMagic(x,a);
		
	}
}
