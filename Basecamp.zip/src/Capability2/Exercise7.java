package Capability2;

import java.util.Scanner;

public class Exercise7 
{
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter your name");
		String n=in.nextLine();
		System.out.println("enter your age");
		int a=in.nextInt();
		char c=n.charAt(0);
		String s=""+c;
		for (int i = 1; i <= n.length()-1; i++) 
		{
			if(n.charAt(i)==' ')
			{
				s=s+n.charAt(i+1);
			}
		}System.out.println(a+s);
	}
	
	
}
