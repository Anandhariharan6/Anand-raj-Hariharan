package Capability2;

import java.util.Scanner;

public class Exercise16 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);

		System.out.println("Enter row");
		int r = sc.nextInt();
		System.out.println("Enter column");
		int c = sc.nextInt();
		int a[][] = new int[r][c];
		for (int i = 0; i < r; i++)
		{
			for (int j = 0; j < c; j++) 
			{
				System.out.println("enter data in x["+i+" "+j+"]position");
				a[i][j] = sc.nextInt();
			}
		}
		row(a);
	}

	public static void row(int ar[][])
		{
		
		int[] sum=new int[ar.length];
		for( int i=0;i<ar.length;i++)
			{
				sum[i]=0;
			}
		for(int i=0;i<ar.length;i++)
		{
			for(int j=0;j<ar.length;j++)
				{
					sum[i]=sum[i]+ar[i][j];
				}
		}
		for(int i=0;i<ar.length-1;i++)
		{
			if(sum[i]==sum[i+1])
			{
				System.out.println("Its row magic!!!");
			}
			else
			{
				System.out.println("Its not a Row magic !!!");
			}
		}
}
}
