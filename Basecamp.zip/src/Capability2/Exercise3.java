package Capability2;

import java.util.Scanner;

//Maximum of 3 numbers
public class Exercise3 {
	public static void getMax(int a,int b,int c)
	{
		if(a>b && a>c)
		{
			System.out.println("greater is:"+a);
		}
		else if(b>a && b>c)
		{
			System.out.println("greater is:"+b);
		}
		else
		{
			System.out.println("greater is:"+c);
		}
	}
	public static void main(String[] args) 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("enter 1st number");
		int a= in.nextInt();
		System.out.println("enter 2nd number");
		int b= in.nextInt();
		System.out.println("enter 3rd number");
		int c= in.nextInt();
		getMax(a,b,c);
	}

}
