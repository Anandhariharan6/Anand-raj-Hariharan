package Capability1;

import java.util.Scanner;

public class Exercise1FactorialUsingWhileLoop1 {
	
	public static void main(String[] args) {
		System.out.println("enter a no.");
		Scanner in = new Scanner(System.in);
		int num;
		num=in.nextInt();
		int factorial = 1;
		int i=1;
		while(i<=num) {
			factorial=factorial*i;
			i++;
		}
		System.out.println("Factorial is="+factorial);
	}

}
