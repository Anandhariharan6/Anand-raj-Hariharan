package Capability1;

import java.util.Scanner;

public class Pyramid {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter a number");
		int d = in.nextInt();
		//int p= d;
		for (int i = 0; i <= d; i++)
		{
			for (int j = d-1; j >=i ; j--) 
			{
					System.out.print(" ");
			}
			for (int r = 1; r <= i; r++)
			{
				System.out.print(i+" ");
			}
			System.out.println();
		}
	}
}
