package Capability1;

import java.util.Scanner;

public class Exercise2Multiplication_of_table2 {

	public static void main(String[] args) {
		System.out.println("enter a no. of which you want table");
		Scanner in = new Scanner(System.in);
		int num= in.nextInt();
		for (int i = 1; i <=12; i++) {
			System.out.println(num+"*"+i+"="+num*i);
		}
	}

}
