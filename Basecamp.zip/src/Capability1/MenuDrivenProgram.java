package Capability1;

import java.util.Scanner;

public class MenuDrivenProgram 
{
	static Scanner in = new Scanner(System.in);

	public static void main(String[] args) 
	{
		boolean flag = true;
		while (flag) 
		{
			System.out.println("1. Find out the fibonacci series upto a particular range");
			System.out.println("2. Print all the prime numbers upto a particular number");
			System.out.println("3. Find out all the factors of a given number");
			int choice = in.nextInt();
			switch (choice) 
			{
			case 1:
				fibonacci();
				break;
			case 2:
				prime();
				break;
			case 3:
				factors();
				break;
			default:
				flag=false;
				break;
			}
		}
	}
	public static void fibonacci()
	{
		
		int n1=1,n2=2,n3;
		System.out.println("enter the length of the fibnacci series");
		int num = in.nextInt();
		System.out.print(n1+" "+n2);
		for(int i=3;i<=num;i++)
		{
			n3=n1+n2;
			System.out.print(" "+n3);
			n1=n2;
			n2=n3;
		}
	}
		public static void prime()
		{
			System.out.println("enter a number upto whic you want prime");
			int n = in.nextInt();
			for(int i=1;i<=n;i++)
			{
				if(check(i))
				{
					System.out.println(i);
				}
			}
		}
		public static boolean check(int n)
		{
			if(n<=1)
				return false;
			for(int i=2;i<=n/2;i++)
			{
				if(n%i==0)
					return false;
			}
			return true;
		}
		
	public static void factors()
	{
		System.out.println("enter a number");
		int f = in.nextInt();
		for (int i = 1; i <=f; i++) 
		{
			if(f%i==0)
			{
				System.out.println("factors are:"+i);
			}
		}
	}
}

