package Capability1;

import java.util.Scanner;

public class Lcm_Gcd_Approach2 {
	public static void lcmgcd()
	{
		System.out.println("enter 1 st numbers");
		System.out.println("enter 2 nd numbers");
		Scanner in = new Scanner(System.in);
		int a = in.nextInt();
		int b = in.nextInt();
		int gcd=1;	
		for (int i = 1; i <a && i<b; i++)
		{
			if(a%i==0 && b%i==0)
			{
				gcd=i;
			}
		}
		System.out.println("GCD is:"+gcd);
		int lcm= a*b/gcd;
		System.out.println("LCM is:"+lcm);
	}

	public static void main(String[] args) {
		Lcm_Gcd_Approach2 lh = new Lcm_Gcd_Approach2();
		lh.lcmgcd();

	}

}
