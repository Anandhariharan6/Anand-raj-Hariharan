package Capability1;

import java.util.Scanner;

public class MenuDrivenTest {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		boolean flag = true;
		while (flag) {
			System.out.println("print pattern:");
			System.out.println("print prime no:");
			int choice = in.nextInt();
			switch (choice) {
			case 1:
				pattern();
				break;
			case 2:
				prime();
			default:
				flag = false;
				break;
			}

		}

	}
	public static void pattern()
	{
		 {
				boolean k = true;
				for (int i = 0; i <= 3; i++) {
					k = true;
					for (int j = 1; j <= 5; j++) {
						if (j >= 4 - i && j <= 2 + i && k) {
							System.out.print("*");
							k = false;
						} else {
							System.out.print(" ");
							k = true;
						}
					}
					System.out.println();
				}

			}
		}
		public static void prime()
		{
			Scanner in = new Scanner(System.in);
			System.out.println("enter a number upto which you want prime");
			int n= in.nextInt();
			for(int i=1;i<=n;i++)
			{
				if(check(i))
				{
					System.out.println(i);
				}
			}
		}
		public static boolean check(int n)
		{
			if(n<=1)
				return false;
			for(int i=2;i<=n/2;i++)
			{
				if(n%i==0)
					return false;
			}
			return true;
		}

	}


