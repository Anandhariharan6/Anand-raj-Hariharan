package Capability1;

import java.util.Scanner;

public class PrintingPrimeNumberUptoAGivenNumber {
	public static boolean check(int n)
	{
		if(n<=1)
			return false;
		for(int i=2;i<=n/2;i++)
		{
			if(n%i==0)
				return false;
		}
		return true;
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter a number upto which you want prime");
		int n= in.nextInt();
		for(int i=1;i<=n;i++)
		{
			if(check(i))
			{
				System.out.println(i);
			}
		}
	}
}
