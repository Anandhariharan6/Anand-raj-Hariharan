package Capability1;

import java.util.Scanner;

public class Fibonacci7 {
	public static void fib(int num)
	{
		int n1=1,n2=2,n3;
		System.out.print(n1+" "+n2);
		for(int i=3;i<=num;i++)
		{
			n3=n1+n2;
			System.out.print(" "+n3);
			n1=n2;
			n2=n3;
		}
	}
	
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter the length of the fibnacci series");
		int num = in.nextInt();
		fib(num);
	}
}
