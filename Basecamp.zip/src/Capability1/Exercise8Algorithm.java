package Capability1;

import java.util.Scanner;

public class Exercise8Algorithm {

	public static void main(String[] args) {
		System.out.println("Enter a :");
		System.out.println("Enter b :");
		Scanner in =new Scanner(System.in);
		for (int i = 0; i <=10; i++) 
		{
			int a = in.nextInt();
			int b = in.nextInt();
			if(a>b || a<=0 || b<=0)
			{
				System.out.println("Invalid");
				System.exit(0);
			}
			else
			{
				a=a+b;
				b=b+10;
			}
			System.out.println(a+" "+b);
		}
	}
}
