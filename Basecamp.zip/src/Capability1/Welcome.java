package Capability1;

public class Welcome {

	public static void main(String[] args) {
		System.out.println("welcome to mindtre kalinga");

	}

}
