package Capability1;

import java.util.Scanner;

public class LotteryTicket9 
	{
	public static void tickets(int a,int b,int c)
	{
	if(a!=b && b!=c && c!=a)
	{
	System.out.println("0");
	}
	else if (a==b && b==c && c==a)
	{
	System.out.println("20");
	}
	else
	{
	System.out.println("10");
	}
	}
	public static void main(String[] args)
	{
	System.out.println("enter the inputs:");
	Scanner in= new Scanner(System.in);
	int a = in.nextInt();
	int b = in.nextInt();
	int c = in.nextInt();
	tickets(a, b,c);
	}
	}
