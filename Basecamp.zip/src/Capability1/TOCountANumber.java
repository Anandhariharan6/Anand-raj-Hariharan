package Capability1;

import java.util.Scanner;

public class TOCountANumber {
	public static void count(int n)
	{
		int count=0;
		while(n>0)
		{
			n=n/10;
			count++;
		}
		System.out.println("Number Of Digits are:"+count);
	}

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		System.out.println("enter a number");
		int n= in.nextInt();
		count(n);
	}

}
