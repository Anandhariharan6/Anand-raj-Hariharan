package Capability1;

import java.util.Scanner;

public class Hailstone_Sequence3 {

	public static void main(String[] args) {
		System.out.println("enter a number");
		Scanner in = new Scanner(System.in);
		int num=in.nextInt();
		int count=0;
		while(num!=1)
		{
			if(num % 2==0)
			{
				System.out.println(num +" is even i.e half "+num/2);
				num=num/2;
			}
			else 
			{
				System.out.println(num +" is odd i.e 3*num+1 "+(3*num+1));
				num=3*num+1;
			}
			count++;
		}
		System.out.println("the process took= "+count+" steps");

	}

}
