package Capability1;

import java.util.Scanner;

public class Intro_TO_Functions5 {
	public static void method() 
	{
		Scanner in = new Scanner(System.in);
		System.out.println("Enter Employee id=");
		int empid=in.nextInt();
		System.out.println("Enter Employee job Band=");
		String job=in.next();
		System.out.println("Enter Department Code=");
		int code=in.nextInt();
		if(job=="C1" || job=="C2" ||job=="C3" || job=="C4" || job=="C5");
			System.out.println("valid job");
			
		if(code>=110 && code<=125)
		{
			System.out.println("code is in range");
		}
	}
	

	public static void main(String[] args) {
		Intro_TO_Functions5 f = new Intro_TO_Functions5();
		f.method();
	}

}
