package Capability1;

import java.util.Scanner;

public class RightAngleTriangle {

	public static void main(String[] args) {
		int i,j;
		{
			System.out.println("enter a number");
			Scanner in = new Scanner(System.in);
			int n= in.nextInt();
			for(i=1;i<=n;i++)
			{
				for (int j1 = 1; j1 <=n; j1++) 
				{
					if(j1<=i)
					System.out.print("*");
					else
					System.out.print(" ");
				}
				System.out.println();
			}
		}

	}

}
