package Capability1;

import java.util.Scanner;

public class Lcm_and_gcd6 {
	public static void lcmhcf()
	{
		int n1, n2;
		int gcd, lcm, rem, numer, den;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two Numbers");
		n1 = sc.nextInt();
		n2 = sc.nextInt();
		if (n1 > n2) {
			numer = n1;
			den = n2;
		}
		else {
			numer = n2;
			den = n1;
		}
		rem = numer % den;
		while (rem != 0) {
			numer = den;
			den = rem;
			rem = numer % den;
		}
		gcd = den;
		lcm = n1 * n2 / gcd;
		System.out.println("GCD of " + n1 + " and " + n2 + " = " + gcd);
		System.out.println("LCM of " + n1 + " and " + n2 + " = " + lcm);
	}

	public static void main(String[] args) 
	{
		Lcm_and_gcd6 l= new Lcm_and_gcd6();
		l.lcmhcf();
	}

}
