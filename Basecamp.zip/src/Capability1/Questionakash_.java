package Capability1;

import java.util.Scanner;

public class Questionakash_ {

	public static void main(String[] args) {
		System.out.println("enter a no.");
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		for (int i = 0; i <= n; i++) 
		{
			if(i%2!=0)
			{
				System.out.println("the no is odd");
			}
		}

	}

}
