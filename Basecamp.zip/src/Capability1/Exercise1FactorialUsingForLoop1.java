package Capability1;

import java.util.Scanner;

public class Exercise1FactorialUsingForLoop1 {

	public static void main(String[] args) {
		System.out.println("enter a no.");
		Scanner in = new Scanner(System.in);
		int num;
		num = in.nextInt();
		int factorial = 1;
		for (int i = 1; i <= num; i++) {

			factorial =factorial * i;
		}
		System.out.printf("Factorial is="+factorial);
	}

}
