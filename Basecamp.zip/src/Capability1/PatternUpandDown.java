package Capability1;

public class PatternUpandDown {

	public static void main(String[] args) {
		boolean k = true;
		for (int i = 0; i <= 3; i++) {
			k = true;
			for (int j = 1; j <= 5; j++) {
				if (j >= 4 - i && j <= 2 + i && k) {
					System.out.print("*");
					k = false;
				} else {
					System.out.print(" ");
					k = true;
				}
			}
			System.out.println();
		}

	}
}
