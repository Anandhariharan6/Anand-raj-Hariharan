package Capability4;

import java.util.Scanner;

public class Demo {

	public static void main(String[] args) {
		
//		Books b = new Books();
//		b.setBookId(21);
//		b.setBookName("Harry potter");
//		b.setAuthorName("Anand");
//  	System.out.println(b.getBookName());
		
		Scanner in = new Scanner(System.in);
		System.out.println("enter no. of books you want");
		int n = in.nextInt();
		Books [] arr = new Books[n];
		
		Library l = new Library();
		l.setLibraryId(1);
		l.setLibraryName("National Library");
		
		for (int i = 0; i < arr.length; i++) 
		{
			arr[i]=new Books();
			arr[i].setBookName("java");
		}
		
		for (int i = 0; i < arr.length; i++)
		{
			System.out.println(arr[i]);
		}		

	}

}
