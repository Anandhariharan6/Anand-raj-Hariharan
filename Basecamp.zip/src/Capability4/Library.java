package Capability4;

import java.util.Arrays;

public class Library {
	private int libraryId;
	private String libraryName;
	private Books[] book;
	public int getLibraryId() {
		return libraryId;
	}
	public void setLibraryId(int libraryId) {
		this.libraryId = libraryId;
	}
	public String getLibraryName() {
		return libraryName;
	}
	public void setLibraryName(String libraryName) {
		this.libraryName = libraryName;
	}
	public Books[] getBook() {
		return book;
	}
	public void setBook(Books[] book) {
		this.book = book;
	}
	@Override
	public String toString() {
		return "Library [libraryId=" + libraryId + ", libraryName=" + libraryName + ", book=" + Arrays.toString(book)
				+ "]";
	}
	
}
