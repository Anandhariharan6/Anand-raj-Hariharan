package com.nindtree.updatedelete;

import java.util.Scanner;

public class mainemp {
	static Scanner in = new Scanner(System.in);
	static emp[] added;
	static emp[] insorted;
	static emp[] updated;
	static emp[] isortedasc;
	static emp bsearched;
	public static void main(String[] args) 
	{
		boolean flag=true;
		do {
			System.out.println("-------MENU---------");
			System.out.println("1-add details");
			System.out.println("2-insertio sort on the basis of salary in desc order.");
			System.out.println("3-update salary of the particlar id entered.");
			System.out.println("4-binary search on the basis of id.");
			System.out.println("5-exit menu.");
			System.out.println("enter the choice.");
			int c = in.nextInt();
			switch (c) {
			case 1:System.out.println("enter the no. of employees you want:");
			int n = in.nextInt();
				emp[] e=new emp[n];
				for (int i = 0; i < e.length; i++)
				{
					e[i]=new emp();
				}
				added=add(e);
				break;
			case 2:insorted=insort(added);
			display(insorted);
			break;
			case 3:updated=update(added);
			display(updated);
			break;
			case 4:isortedasc=insortasc(added);
			System.out.println("enter the id you want to search:");
			int key = in.nextInt();
			bsearched=bsearch(isortedasc,key);
			 System.out.println("id is: "+bsearched.getId());
			 System.out.println("f name is"+bsearched.getFname());
			 System.out.println("l name is :"+bsearched.getLname());
			 System.out.println("salary is:"+bsearched.getSalary());
			break;
			case 5:
				flag=false;
				System.out.println("out of menu.");
			default:
				System.out.println("enter a valid choice.");
				break;
			}
			
		} while (flag);

	}
	private static emp bsearch(emp[] b, int key) 
	{
		int l=0;
		int h=b.length-1;
		int mid;
		while(l<=h)
		{
			mid=(l+h)/2;
			if(b[mid].getId()==(key))
				return b[mid];
			else if(b[mid].getId()>(key))
			{
				h=mid-1;
			}
			else
			{
				l=mid+1;
			}
		}
		return null;
	}
	private static emp[] add(emp[] e) 
	{
		for (int i = 0; i < e.length; i++) 
		{
			System.out.println("enter id:");
			e[i].setId(in.nextInt());
			in.nextLine();
			System.out.println("enter f name:");
			e[i].setFname(in.nextLine());
			System.out.println("enter l name:");
			e[i].setLname(in.nextLine());
			System.out.println("enter salary:");
			e[i].setSalary(in.nextInt());
			in.nextLine();
			
		}
		return e;
	}
	
	private static emp[] insort(emp[] added2)
	{
	
		emp temp;
		int j;
		for (int i = 1; i < added2.length; i++)
		{
			j=i-1;
			temp=added2[i];
			while(j>=0 && (added2[j].getId()<temp.getId()))
			{
				added2[j+1]=added2[j];
				j=j-1;
			}added2[j+1]=temp;
		}
		return added2;
	}
	private static emp[] update(emp[] added2) {
		System.out.println("enter the id of which you want to update the slary:");
		int id=in.nextInt();
		for (int i = 0; i < added2.length; i++) 
		{
			
			if(added2[i].getId()==id)
				{
					int p=added2[i].getSalary()+5000;
							added2[i].setSalary(p);
							System.out.println(p);
				}
		}
		return added2;
	}
	private static emp[] insortasc(emp[] added2)
	{
		emp temp;
		int j;
		for (int i = 1; i < added2.length; i++)
		{
			j=i-1;
			temp=added2[i];
			while(j>=0 && (added2[j].getId()>temp.getId()))
			{
				added2[j+1]=added2[j];
				j=j-1;
			}added2[j+1]=temp;
		}
		return added2;
	}
	private static void display(emp[] d)
	{
		for (int i = 0; i < d.length; i++)
		{
			System.out.print("id is:"+d[i].getId());
			System.out.print("enter f name :"+d[i].getFname());
			System.out.print("enter l name: "+d[i].getLname());
			System.out.print("enet salary"+d[i].getSalary());
			System.out.println();
		}
	}

}
