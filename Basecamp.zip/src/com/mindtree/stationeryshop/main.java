package com.mindtree.stationeryshop;

import java.util.Scanner;

import com.mindtree.shop.Shop;

public class main 
{
	static Scanner in=new Scanner(System.in);
	static StationeryShop added[];
	static StationeryShop done[];
	static StationeryShop res;
	static StationeryShop done1;
	public static void main(String[] args) 
	{
		boolean flag=true;
		do 
		{
			System.out.println("----menu------");
			System.out.println("1.Add Shop");
			System.out.println("2.sorting on the basis of revenue and search on the basis of name");
			System.out.println("3.dispaly all shops having revenue >20000 and having more tha 5 products");
			System.out.println("4.display all the shops having a or i in the name attribute");
			System.out.println("enter your choice");
			int choice = in .nextInt();
			switch(choice)
			{
			case 1:
				System.out.println("enter the no. of shops you want:");
			int n=in.nextInt();
			in.nextLine();
			StationeryShop [] sadd=new  StationeryShop[n];
			for (int i = 0; i < n; i++) 
			{
				sadd[i]=new StationeryShop();
			}
			added=addshop(sadd);
			break;
			case 2:
				in.nextLine();
				done=sortingandsearching(added);
			break;
			case 3:res=revenue(done);
			System.out.println(res.getName());
			System.out.println(res.getNoofitemsavailable());
			System.out.println(res.getRevenue());
			break;
			case 4:done1=shopswithIA(done);
			System.out.println(done1.getName());
			System.out.println(done1.getNoofitemsavailable());
			System.out.println(done1.getRevenue());
			break;
			}
			
		} while (flag);

	}
	private static StationeryShop[] addshop(StationeryShop [] sadd)
	{
		for (int i = 0; i < sadd.length; i++) 
		{
			System.out.println("enter shop name:");
			sadd[i].setName(in.nextLine());
			System.out.println("enter number of items available:");
			sadd[i].setNoofitemsavailable(in.nextInt());
			in.nextLine();
			System.out.println("enter revenue:");
			sadd[i].setRevenue(in.nextInt());
			in.nextLine();
		}
		return sadd;
	}
	private static StationeryShop[] sortingandsearching(StationeryShop[] added2) 
	{
		for (int i = 1; i < added2.length; i++)
		{
			int j=i;
			StationeryShop temp=added2[j];
			while(j>0)
			{
				if(temp.getNoofitemsavailable()<added2[j-1].getNoofitemsavailable())
				added2[j]=added2[j-1];
				j=j-1;
			}
			
			added2[j]=temp;
		}
			System.out.println("enter the name of shop you want to search:");
			String searchname=in.nextLine();
			for (int k = 0; k < added2.length; k++)
			{
				if(added2[k].getName().equals(searchname))
				{
					System.out.println("shop name:"+added2[k].getName());
					System.out.println("items available"+added2[k].getNoofitemsavailable());
					System.out.println("the revenue is:"+added2[k].getRevenue());
					break;
				}
			}
			return added2;
		}
		
	
	private static StationeryShop revenue(StationeryShop[] done2) 
	{
		StationeryShop result=null;
		for(int i=0;i<done2.length;i++)
		{
			if(done2[i].getRevenue()>20000 && done2[i].getNoofitemsavailable()==5)
			{
				result=done2[i];
			}
		}
		return result;
		
	}
	private static StationeryShop shopswithIA(StationeryShop[] done2)
	{
		for (int i = 0; i < done2.length; i++) 
		{
			for (int j = 0; j < done2[i].getName().length() ; j++)
			{
				if(done2[i].getName().charAt(j)=='a')
				{
					for (int j2 = 0; j2 <done2[i].getName().length(); j2++) {
						if(done2[i].getName().charAt(j2)=='i')
						{
							System.out.println(done2[i].getName());
						}
						
					}
				}
			}
		}
		return done1;
		
	}

}
