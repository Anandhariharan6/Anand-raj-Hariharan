package com.mindtree.stationeryshop;

public class StationeryShop 
{
	private String name;
	private int noofitemsavailable;
	private int revenue;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNoofitemsavailable() {
		return noofitemsavailable;
	}
	public void setNoofitemsavailable(int noofitemsavailable) {
		this.noofitemsavailable = noofitemsavailable;
	}
	public int getRevenue() {
		return revenue;
	}
	public void setRevenue(int revenue) {
		this.revenue = revenue;
	}
	@Override
	public String toString() {
		return "StationeryShop [name=" + name + ", noofitemsavailable=" + noofitemsavailable + ", revenue=" + revenue
				+ "]";
	}
	
}
