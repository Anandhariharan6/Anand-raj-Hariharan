package com.mindtree.student;

import java.util.Scanner;

public class main {
	static Scanner in = new Scanner (System.in);
	static Student[] added;
	static Student searched;
	
	public static void main(String[] args)
	{
		boolean flag = true;
		do {
			System.out.println("1.add value");
			System.out.println("2.insertion sort on names in desc order");
			System.out.println("3.bubble sort in id and binary search on names");
			System.out.println("enter your choice");
			int c= in.nextInt();
			in.nextLine();
			switch (c) 
			{
			case 1:
				System.out.println("enter the no. of students you want to add:");
				int n = in.nextInt();
				in.nextLine();
				Student[] st=new Student[n];
				for (int i = 0; i < st.length; i++) 
				{
					st[i]=new Student();
				}
				added=add(st);
				display(added);
				break;
			case 2: added=insorting(added);
			display(added);
			break;
			case 3:searched=bsearching(added);
			System.out.println("id is: "+searched.getId());
			System.out.println("name is: "+searched.getName());
			System.out.println("marks is: "+searched.getMarks());
			default:
				break;
			}
			
		} while (flag);

	}
		
	
	private static Student bsearching(Student[] b) {
		// TODO Auto-generated method stub
		System.out.println("Enter the name to be searched.");
		String key=in.nextLine();
		int l=0;
		int h=b.length-1;
		int mid;
		while(l<=h)
		{
			mid=(l+h)/2;
			if(b[mid].getName().equals(key))
				return b[mid];
			else if(b[mid].getName().compareTo(key)>0)
			{
				h=mid-1;
			}
			else
			{
				l=mid+1;
			}
		}
		return null;
	}
	


	private static Student[] bsorted(Student[] added2) 
	{
		for (int i = 0; i < added2.length-1; i++) 
		{
			for (int j = 0; j < added2.length-i-1; j++)
			{
				if(added2[j].getId().compareTo(added2[j+1].getId())>0)
				{
					Student temp = added2[j];
					added2[j] = added2[j+1];
					added2[j+1] = temp;
				}
				
			}
		}
		return added2;
	}
	private static Student[] insorting(Student[] added2) 
	{
		Student temp;
		int j;
		for (int i = 1; i < added2.length; i++)
		{
			j=i-1;
			temp=added2[i];
			while(j>=0 && added2[j].getName().compareTo(temp.getName())>0)
			{
				added2[j+1]=added2[j];
				j=j-1;
			}added2[j+1]=temp;
		}
		return added2;
	}
	private static Student[] add(Student[] st) 
	{
		for (int i = 0; i < st.length; i++) 
		{
			System.out.println("enter id: ");
			st[i].setId(in.nextLine());
			System.out.println("enter names: ");
			st[i].setName(in.nextLine());
			System.out.println("enter marks: ");
			st[i].setMarks(in.nextInt());
			in.nextLine();
		}
		return st;
	}
	private static void display(Student[] d)
	{
		for (int i = 0; i < d.length; i++) {
			System.out.println("id is: "+d[i].getId());
			System.out.println("name is: "+d[i].getName());
			System.out.println("marks is:"+d[i].getMarks());
			System.out.println();
		}
	}

}
