package com.mindtree.leadandmind;

public class campusmind {
	private int id;
	private String name;
	private int age;
	private String branch;
	private int capability;
	public campusmind(int id, String name, int age, String branch, int capability) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.branch = branch;
		this.capability = capability;
	}
	public campusmind() {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public int getCapability() {
		return capability;
	}
	public void setCapability(int capability) {
		this.capability = capability;
	}
	@Override
	public String toString() {
		return "campusmind [id=" + id + ", name=" + name + ", age=" + age + ", branch=" + branch + ", capability="
				+ capability + "]";
	}
	

}
