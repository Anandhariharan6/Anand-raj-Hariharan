package com.mindtree.leadandmind;

import java.util.Arrays;

public class lead {
	private String lname;
	private campusmind[] minds;
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public campusmind[] getMinds() {
		return minds;
	}
	public void setMinds(campusmind[] minds) {
		this.minds = minds;
	}
	@Override
	public String toString() {
		return "lead [lname=" + lname + ", minds=" + Arrays.toString(minds) + "]";
	}
	

}
