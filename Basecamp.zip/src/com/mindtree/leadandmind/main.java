package com.mindtree.leadandmind;

import java.util.Scanner;

public class main {
	static Scanner in = new Scanner(System.in);
	static int k;
	static lead[] L=new lead[10];
 	public static void main(String[] args) 
	{		
		boolean flag=true;
		do 
		{
			System.out.println("-----menu-------");
			System.out.println("1.regestration of campus mind");
			System.out.println("2.update the capability");
			System.out.println("3.sort on the basis of capabity");
			System.out.println("4.search on the basis of campus mind or lead");
			System.out.println("5.display");
			System.out.println("enter you choice");
			int choice = in.nextInt();
			in.nextLine();
			switch (choice) {
			case 1:regestration();
			break;
			case 2:update();
			break;
			case 3:sort();
			break;
			case 4:search();
			break;
			case 5:display();		
			break;
			}
			
		} while (flag);

	}

	private static void regestration() 
	{
		L[k]= new lead();
		System.out.println("enter the lead name:");
		L[k].setLname(in.nextLine());
		System.out.println("enter no. of students undre him/her:");
		int noofMind=in.nextInt();
		in.nextLine();
		campusmind[] cm=new campusmind[noofMind];
		for (int i = 0; i < noofMind; i++)
		{
			cm[i]=new campusmind();
			System.out.println("enter the id:");
			cm[i].setId(in.nextInt());
			in.nextLine();
			System.out.println("enter name:");
			cm[i].setName(in.nextLine());
			System.out.println("enter age:");
			cm[i].setAge(in.nextInt());
			in.nextLine();
			System.out.println("enter the branch:");
			cm[i].setBranch(in.nextLine());
			System.out.println("enter the no. of capability: ");
			cm[i].setCapability(in.nextInt());
			in.nextLine();
			
		}
		L[k].setMinds(cm);
		k++;
		
	}

	private static void update() {
		System.out.println("enter lead name:");
		String lname=in.nextLine();
		for (int i = 0; i < k; i++)
		{
			if(L[i].getLname().equals(lname))
			{
				campusmind[] c= L[k].getMinds();
				System.out.println("enter student name:");
				String sname=in.nextLine();
				for (int j = 0; j < c.length; j++) 
				{
					if(c[j].getName().equals(sname))
					{
						System.out.println("enter the updated capability value:");
						c[j].setCapability(in.nextInt());
						in.nextLine();
						System.out.println("successfully updated");
						System.out.println("Student name:"+c[j].getName());
						System.out.println("no of capability moved"+c[j].getCapability());
						System.out.println();
					}
				}
			}
		}
		
	}

//	private static void sort() 
//	{
//		System.out.println("enter lead name:");
//		String lname=in.nextLine();
//		for (int i = 0; i < k; i++)
//		{
//			if(L[i].getLname().equals(lname))
//			{
//				campusmind[] c= L[i].getMinds();
//				for (int j = 0; j < c.length; j++) 
//				{
//					for (int j2 = 0; j2 < c.length-j-1; j2++) 
//					{
//						if(c[j2].getCapability()>c[j2+1].getCapability())
//						{
//							campusmind temp=c[j2];
//							c[j2]=c[j2+1];
//							c[j2+1]=temp;
//						}
//					}
//				}
//			}
//		}
//		
//	}
	private static void sort()
	{
		System.out.println("enter the lead name:");
		String lname=in.nextLine();
		for (int i = 0; i < k; i++) 
		{
			if(L[i].getLname().equals(lname))
			{
				campusmind[] c=L[i].getMinds();
				for (int j = 1; j < c.length; j++) 
				{
					int h=j;
					campusmind temp = c[j];
					while(h>0)
					{
						if(temp.getCapability()<c[h-1].getCapability()) 
						{
						c[h]=c[h-1];
						h=h-1;
						}
						else if(temp.getCapability()==c[h-1].getCapability() && temp.getName().compareTo(c[h-1].getName())<0)
						{
							c[h]=c[h-1];
							h=h-1;
						}
					}
					c[h]=temp;
				}
				
			}
		}
	}

	private static void search() 
	{
		System.out.println("1-Search by student name");
		System.out.println("2-Search by leads of team");
		int choice=in.nextInt();
		in.nextLine();
		switch (choice) {
		case 1:
			System.out.println("enter campus mind name:");
			String sname=in.nextLine();
			for (int i = 0; i < k; i++) 
			{
				campusmind[] c= L[i].getMinds();
				for (int j = 0; j < c.length; j++) 
				{
					if(c[j].getName().equals(sname))
					{
						System.out.println("id:"+c[j].getId());
						System.out.println("Name:"+c[j].getName());
						System.out.println("Age:"+c[j].getAge());
						System.out.println("Branch:"+c[j].getBranch());
						System.out.println("capability:"+c[j].getCapability());
						System.out.println("lead name:"+L[i].getLname());
						System.out.println();
					}
				}
			}
			
			break;

		case 2:
			System.out.println("enter lead name:");
			String lname=in.nextLine();
			for (int i = 0; i < k; i++)
			{
				campusmind[] c= L[i].getMinds();
				if(L[i].getLname().equals(lname)) 
				{
					System.out.println("students under "+L[i].getLname());
					for (int j = 0; j < c.length; j++) 
					{
						System.out.println("id:"+c[j].getId());
						System.out.println("Name:"+c[j].getName());
						System.out.println("Age:"+c[j].getAge());
						System.out.println("Branch:"+c[j].getBranch());
						System.out.println("capability:"+c[j].getCapability());
						System.out.println();
					}
				}
			}
			break;
		}
		
	}

	private static void display() {
		for (int i = 0; i < k; i++) 
		{
			System.out.println("Students under: "+L[i].getLname());
			campusmind[] c= L[i].getMinds();
			for (int j = 0; j < c.length; j++) 
			{

				System.out.println("id:"+c[j].getId());
				System.out.println("Name:"+c[j].getName());
				System.out.println("Age:"+c[j].getAge());
				System.out.println("Branch:"+c[j].getBranch());
				System.out.println("capability:"+c[j].getCapability());
				System.out.println();
			}
			
		}
		
	}

}
