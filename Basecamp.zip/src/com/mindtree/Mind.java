package com.mindtree;

public class Mind {
	int mid;
	String manme;
	int mage;
	String branch;
	int cm;
	public int getMid() {
		return mid;
	}
	public void setMid(int mid) {
		this.mid = mid;
	}
	public String getManme() {
		return manme;
	}
	public void setManme(String manme) {
		this.manme = manme;
	}
	public int getMage() {
		return mage;
	}
	public void setMage(int mage) {
		this.mage = mage;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public int getCm() {
		return cm;
	}
	public void setCm(int cm) {
		this.cm = cm;
	}
	@Override
	public String toString() {
		return "Mind [mid=" + mid + ", manme=" + manme + ", mage=" + mage + ", branch=" + branch + ", cm=" + cm + "]";
	}

}
