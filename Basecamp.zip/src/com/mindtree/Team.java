package com.mindtree;

import java.util.Arrays;

public class Team {
	String Lname;
	Mind[] mind;
	public String getLname() {
		return Lname;
	}
	public void setLname(String lname) {
		Lname = lname;
	}
	public Mind[] getMind() {
		return mind;
	}
	public void setMind(Mind[] mind) {
		this.mind = mind;
	}
	@Override
	public String toString() {
		return "Team [Lname=" + Lname + ", mind=" + Arrays.toString(mind) + "]";
	}
	

}
