package com.mindtree.shop;

public class Shop {
	private int id;
	private String name;
	private double revenu;
	private int gstnumber;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getRevenu() {
		return revenu;
	}
	public void setRevenu(double revenu) {
		this.revenu = revenu;
	}
	public int getGstnumber() {
		return gstnumber;
	}
	public void setGstnumber(int gstnumber) {
		this.gstnumber = gstnumber;
	}
	@Override
	public String toString() {
		return "Shop [id=" + id + ", name=" + name + ", revenu=" + revenu + ", gstnumber=" + gstnumber + "]";
	}
	

}
