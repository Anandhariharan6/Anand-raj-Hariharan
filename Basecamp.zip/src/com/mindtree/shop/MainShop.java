package com.mindtree.shop;

import java.util.Scanner;

public class MainShop {
	static Scanner in=new Scanner(System.in);
	static Shop[] sorted;
	static Shop[] added;
	static Shop thirdrevenue;
	public static void main(String[] args) 
	{
		
		boolean flag = true;
		while(true) {
			System.out.println("menu");
			System.out.println("1.Add shop");
			System.out.println("2.Sorting based on GST number");
			System.out.println("3.Shop details havingthe third higest revenu and difference between the first and third");
			System.out.println("4.Search for the partcular shop by id");
			System.out.println("Enter your choice");
			int choice=in.nextInt();
			in.nextLine();
			switch (choice) 
			{
			case 1:
				System.out.println("enter the number of shops");
				 int n=in.nextInt();
				 in.nextLine();
				Shop [] sadd=new Shop[n];
				for(int i=0;i<n;i++)
				{
					sadd[i]=new Shop();
				}
				added=addshop(sadd);
				display(added);
//				for (int i = 0; i < added.length; i++) {
//					System.out.println("id: "+added[i].getId());
//					System.out.println("name: "+added[i].getName());
//					System.out.println("revenue: "+added[i].getRevenu());
//					System.out.println("GST: "+added[i].getGstnumber());
//				}
			break;
			case 2:
				sorted=sorting(added);
				display(sorted);
//			     for (int i = 0; i < sorted.length; i++) {
//				System.out.println("id: "+sorted[i].getId());
//				System.out.println("name: "+sorted[i].getName());
//				System.out.println("revenue: "+sorted[i].getRevenu());
//				System.out.println("GST: "+sorted[i].getGstnumber());
//			}
			break;
			case 3:thirdrevenue=revenue(sorted);
				System.out.println("id: "+thirdrevenue.getId());
				System.out.println("name: "+thirdrevenue.getName());
				System.out.println("revenue: "+thirdrevenue.getRevenu());
				System.out.println("GST: "+thirdrevenue.getGstnumber());
			break;
			case 4:searchid(sorted);
			break;
			default:
				System.out.println("invalid input");
			break;
			}
		} 

	}

	

	private static void display(Shop[] added2) 
	{
		 for (int i = 0; i < added2.length; i++) {
				System.out.println("id: "+added2[i].getId());
				System.out.println("name: "+added2[i].getName());
				System.out.println("revenue: "+added2[i].getRevenu());
				System.out.println("GST: "+added2[i].getGstnumber());
		 }
	}



	private static void searchid(Shop[] sorted2)
	{
	
		System.out.println("enter the id you want to find:");
		int id=in.nextInt();
		in.nextLine();
		
		for (int i = 0; i < sorted2.length; i++)
		{
			if(sorted2[i].getId()==id)
			{
				System.out.println("id: "+sorted2[i].getId());
				System.out.println("name: "+sorted2[i].getName());
				System.out.println("revenue: "+sorted2[i].getRevenu());
				System.out.println("GST: "+sorted2[i].getGstnumber());
				break;
			}
		}		
	}

	private static Shop[] addshop(Shop[] sadd) {
		
		for (int i = 0; i < sadd.length; i++) 
		{
			System.out.println("enter shop id:");
			sadd[i].setId(in.nextInt());
			in.nextLine();
			System.out.println("enter shop name:");
			sadd[i].setName(in.nextLine());
			System.out.println("enter revenue:");
			sadd[i].setRevenu(in.nextDouble());
			in.nextLine();
			System.out.println("enter GST number");
			sadd[i].setGstnumber(in.nextInt());
			in.nextLine();
		}
		return sadd;
	}

	private static Shop[] sorting(Shop[] s2added)
	{
		for (int i = 1; i < s2added.length; i++) 
		{
			int p=i;
			Shop temp = s2added[i];
			while(p>0)
			{
				if(temp.getGstnumber()<s2added[p-1].getGstnumber())
				{
					s2added[p]=s2added[p-1];
					p=p-1;
				}
			}
			s2added[p]=temp;
		}
		return s2added;
		
	}

	private static Shop revenue(Shop[] sorted2)
	{
		Shop thirdshop=null;
		System.out.println(sorted2.length);
		for (int i = sorted2.length-1; i > 0; i--) 
		{
			if(i==sorted2.length-3)
			{
				thirdshop=sorted2[i];
				break;
			}
		}
		
		return thirdshop;
	}

	

}
