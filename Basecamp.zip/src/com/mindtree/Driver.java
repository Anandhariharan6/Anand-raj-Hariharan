package com.mindtree;

import java.util.Scanner;

public class Driver {
	static Scanner in = new Scanner(System.in);
	static Team T[]=new Team[10]; 
	static int k;
	public static void main(String[] args) {
		boolean flag=true;
		do {
			System.out.println("1.registerng team");
			System.out.println("2.updating capabilities by there lead");
			System.out.println("3.sorting on basis of capabilities moved");
			System.out.println("4.Searching for campus mind and there lead name");
			System.out.println("5.exit");
			int c=in.nextInt();
			switch (c) {
			case 1:
				{
					register();
				}
				break;
			case 2:
			{
				update();
			}
			break;
			case 3:
			{
				sort();
			}
			break;
			case 4:
			{
				search();
			}
			break;
			case 5:
			{
				display();
			}
			break;
			case 6:
			{
				System.exit(0);
			}
			break;
			default:
				break;
			}
		} while (flag);

	}

	public static void register()
	{
		T[k]=new Team();
		System.out.println("enter lead name:");
		String leadName = in.nextLine();
		in.nextLine();
		T[k].setLname(leadName);
		System.out.println("enter the number of minds under him:");
		int noOfMind=in.nextInt();
		in.nextLine();
		Mind cm[]= new Mind[noOfMind];
		for (int i = 0; i < noOfMind; i++) {
			cm[i]=new Mind();
			System.out.println("enter mid of mind:");
			int mid=in.nextInt();
			in.nextLine();
			cm[i].setMid(mid);
			System.out.println("enter name of mind:");
			String Mname=in.nextLine();
			cm[i].setManme(Mname);
			System.out.println("enter age of mind:");
			int Mage=in.nextInt();
			in.nextLine();
			cm[i].setMage(Mage);
			System.out.println("enter branch of mind:");
			String Mbranch=in.nextLine();
			cm[i].setBranch(Mbranch);
			System.out.println("enter the capabilities moved of the mind:");
			int Cmoved=in.nextInt();
			in.nextLine();
			cm[i].setCm(Cmoved);
		}
		T[k].setMind(cm);
		k++;
		
	}

	public static void update() {
		System.out.println("enter the lead name :");
		String lname=in.nextLine();
		in.nextLine();
		int flag=0, flag1=0;
		for (int i = 0; i < k; i++) 
		{
			if(T[i].Lname.equals(lname))
			{
				System.out.println("enter the mind you want to find:");
				String mname=in.nextLine();
				Mind cm[] = T[i].getMind();
				for (int j = 0; j < cm.length; j++) 
				{
					if(cm[j].manme.equals(mname))
					{
						System.out.println("enter the updated value of capability");
						cm[j].setCm(in.nextInt());
						in.nextLine();
						System.out.println("updated ");
						System.out.println("Student name:"+cm[j].getManme());
						System.out.println("no of capability moved"+cm[j].getCm());
						System.out.println();
					}
				}
			}
			else
			{
				System.out.println("lead not found");
				System.out.println();
			}
		}
	}

	public static void sort() {
		
		
	}

	public static void search()
	{
		System.out.println("1-search by campus mind name");
		System.out.println("2-search by lead name: ");
		int choice=in.nextInt();
		in.nextLine();
		switch (choice)
		{
		case 1: 
			System.out.println("enter campus mind name");
			String Mname=in.nextLine();
			for (int i = 0; i <k; i++) 
			{
				Mind [] cm= T[i].getMind();
				for (int j = 0; j < cm.length; j++) 
				{
					if (cm[j].getManme().equals(Mname)) 
					{
						System.out.println("id:"+cm[j].getMid());
						System.out.println("name:"+cm[j].getManme());
						System.out.println("age"+cm[j].getMage());
						System.out.println("branch"+cm[j].getBranch());
						System.out.println("capabiliy"+cm[j].getCm());
						System.out.println("lead"+T[i].getLname());
						
					}
					
				}
			
			}
			
			break;
		case 2: System.out.println("enter lead name:");
		String Lname=in.nextLine();

		for (int i = 0; i < k; i++)
		{
	       Mind[] cm2 = T[i].getMind();
		   if(T[i].getLname().equals(Lname))
		   {
			   		System.out.println("student under"+Lname+ " lead");
			   		for (int j = 0; j < cm2.length; j++) 
			   		{
					
					System.out.println("id"+cm2[j].getMid());
					System.out.println("name"+cm2[j].getManme());
					System.out.println("age"+cm2[j].getMage());
					System.out.println("branch"+cm2[j].getBranch());
					System.out.println("capability"+cm2[j].getCm());
			   		}
				
				}
			}
			break;
			}
		}
		

	public static void display() 
	{
		for (int i = 0; i < k; i++) 
		{
			Mind cm[]=T[i].getMind();
			for (int j = 0; j < cm.length; j++) 
			{
				System.out.println(cm[j].toString());
			}
		}
	}


}
