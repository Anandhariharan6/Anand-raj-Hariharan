package com.mindtree.campusmindgetset;

import java.util.Scanner;

import com.mindtree.campusmind.CampusMind;

public class Main {
	static Scanner in = new Scanner(System.in);
	static Mind[] added;
	static Mind[] sorted;
	static Mind[] bsorted;
	static Mind[]  bsearch;
	public static void main(String[] args) 
	{
		boolean flag=true;
		do {
			
			System.out.println("-----menu----");
			System.out.println("1.add values");
			System.out.println("2.insertion sort  on name in desc order");
			System.out.println("3.bubble sort based on name");
			System.out.println("4.search mid based on binary search and dispaly proper message");
			System.out.println("5.search campumind,if found update capability");
			System.out.println("enter your choice:");
			int c= in.nextInt();
			switch (c) {
			case 1:
			System.out.println("enter the number of students you want:");
			int n=in.nextInt();
			Mind[] m= new Mind[n];
			for (int i = 0; i < m.length; i++)
			{
				m[i]=new Mind();
			}
			
			added=add(m);
				break;
			case 2:
			sorted=sorting(added);
			display(sorted);
			break;
			case 3:
			bsorted=buble(added);
			display(bsorted);
				break;
			case 4:
			bsearch=buble(added);
			in.nextLine();
			System.out.println("entet the id you want to search:");
			String key=in.nextLine();
			int y=search(bsearch,key);
			if(y==-1)
			{
				System.out.println("elemet not found:");
			}
			else
			{
				System.out.println("mid is: "+bsearch[y].getMid());
				System.out.println("name : "+bsearch[y].getName());
				System.out.println("capability moved: "+bsearch[y].getCap());
			}
				break;
			case 5:
				break;
			default:
				break;
			}
		} while (flag);

	}
	private static Mind[] add(Mind[]  m) 
	{
		for (int i = 0; i < m.length; i++) 
		{
			in.nextLine();
			System.out.println("enter mid:");
			m[i].setMid(in.nextLine());
			System.out.println("enter name:");
			m[i].setName(in.nextLine());
			System.out.println("enter cap");
			m[i].setCap(in.nextInt());
			
		}
		return m;
	}
	
	private static Mind[] sorting(Mind[] added2) {
		Mind temp;
		int j;
		for (int i = 1; i < added2.length; i++)
		{
			j=i-1;
			temp=added2[i];
			while(j>=0 && added2[j].getName().compareTo(temp.getName())<0)
			{
				added2[j+1]=added2[j];
				j=j-1;
			}added2[j+1]=temp;
		}
		return added2;
	}
	
	private static Mind[] buble(Mind[] sorted2)
	{
		for (int i = 0; i < sorted2.length; i++) 
		{
			for (int j = 0; j < sorted2.length-1; j++)
			{
				if(sorted2[j].getName().compareTo(sorted2[j+1].getName())>0)
				{
					Mind temp = sorted2[j];
					sorted2[j] = sorted2[j+1];
					sorted2[j+1] = temp;
				}
				
			}
		}
		return sorted2;
	}
	private static int search(Mind[] bsearch2, String key) {
		int l=0;
		int h=bsearch2.length-1;
		bsearch=buble(bsearch2);
		while(l<=h)
		{
			int mid=(l+h)/2;
			
			if(bsearch2[mid].getName().equals(key))
			{
				return mid;
			}
			else if(bsearch2[mid].getName().compareTo(key)>0)
			{
				h=mid-1;
			}
			else
			{
				l=mid+1;
			}
		}
		return -1;
	}


	
	
	private static void display(Mind[] d)
	{
		for (int i = 0; i < d.length; i++)
		{
			System.out.println("mid is : "+d[i].getMid());
			System.out.println("name is: "+d[i].getName());
			System.out.println("capability moved: "+d[i].getCap());
			System.out.println();
		}
	}

}
