package com.mindtree.campusmindgetset;

public class Mind 
{
	private String mid;
	private String name;
	private int cap;
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getCap() {
		return cap;
	}
	public void setCap(int cap) {
		this.cap = cap;
	}
	@Override
	public String toString() {
		return "Mind [mid=" + mid + ", name=" + name + ", cap=" + cap + "]";
	}
	
}
