package com.mindtree.campusmind;

import java.util.Scanner;

public class Main {
	
//	public static CampusMind[] getInput(CampusMind[] c)
//	{
//		for(int i=0;i<c.length;i++) {
//			cin.nextLint();
//			System.out.println("enter id");
//			int id=cin.nextInt();
//					
//			
//			
//			
//		System.out.println("enter name ");
//		String name =cin.nextLine();
//		System.out.println("enter id");
//		int cap=cin.nextInt();
//		c[i]=new CampusMind(id,name,cap);
//				}
//	}
//	public static Oyutput(CampusMind[] c)
//	{
//		for(int i=0;i<c.length;i++)
//		{
//			System.out.println("name is "+c[i].getClass());
//		}
//	}
	
	static Scanner in = new Scanner(System.in);
	static CampusMind[] added;
	static CampusMind[] insertionsorted;
	static CampusMind[] bubblesorted;
	static CampusMind[] binarysearched;
	static CampusMind[] largest;
	static CampusMind[] updated;
	public static void main(String[] args)
	{
		System.out.println("enter the number of students you want:");
		int n=in.nextInt();
		CampusMind[] campus=new CampusMind[n];
		boolean flag=true;
		do {
			System.out.println("-----menu----");
			System.out.println("1.add values");
			System.out.println("2.insertion sort based on mid");
			System.out.println("3.bubble sort based on name");
			System.out.println("4.search mid based on binary search");
			System.out.println("5.search campumind,highest base camp capability moved");
			System.out.println("6.update the capability of the used");
			System.out.println("enter your choice:");
			int choice=in.nextInt();
			switch (choice) 
			{
			case 1:added=add(campus);
				break;
			case 2:insertionsorted=insort(added);
			display(insertionsorted);
				break;
			case 3:bubblesorted=bsort(added);
			display(bubblesorted);
				break;
			case 4:binarysearched=insort(added);
			in.nextLine();
			System.out.println("enter the mid you want to search:");
			String key=in.nextLine();
			int y=binarysearch(binarysearched,key);
			if(y==-1)
			{
				System.out.println("elemnt npt found");
			}
			else
			{
				System.out.println("mid is: "+binarysearched[y].C_Mid);
				System.out.println("name : "+binarysearched[y].Name);
				System.out.println("capability moved: "+binarysearched[y].cap_moved);
			}
				break;
			case 5:
				int s=large(added);
				for(int i=0;i<added.length;i++)
				{
					if(s==added[i].cap_moved)
					{
						System.out.println("name is "+added[i].Name);
					}
				}
				break;
			case 6:System.out.println("Enter the id you want to update the capabiliy of:");
				int up = in.nextInt();
				in.nextLine();
				for (int i = 0; i < added.length; i++) {
					if(added[i].C_Mid.equals(up))
					{
						System.out.println();
						added[i].cap_moved=
					}
				}
			}
		} while (flag);

	}
//	private static CampusMind[] update(CampusMind[] insertionsorted2, int up) 
//	{
//		for (int i = 0; i < insertionsorted2.length; i++) 
//		{
//			if(up==in)
//		}
//		return null;
//	}
	private static int large(CampusMind[] a) {
		int temp=a[0].cap_moved;
		for (int i = 1; i < a.length; i++)
		{
			if(a[i].cap_moved>temp)
				temp=a[i].cap_moved;
		}
		return temp;
	}
	private static int binarysearch(CampusMind[] b, String key)
	{
		int l=0;
		int h=b.length-1;
		int mid;
		while(l<=h)
		{
			mid=(l+h)/2;
			if(b[mid].C_Mid.equals(key))
				return mid;
			else if(b[mid].C_Mid.compareTo(key)>0)
			{
				h=mid-1;
			}
			else
			{
				l=mid+1;
			}
		}
		return -1;
	}
	private static CampusMind[] add(CampusMind[] campus) {
		for (int i = 0; i < campus.length; i++)
		{
			in.nextLine();
			System.out.println("enter mid:");
			String mid=in.nextLine();
			System.out.println("enter name:");
			String name=in.nextLine();
			System.out.println("enter the capabilities moved:");
			int cap=in.nextInt();
			campus[i]=new CampusMind(mid,name,cap);
			
		}
		return campus;
	}
	private static CampusMind[] insort(CampusMind[] added2)
	{
		CampusMind temp;
		int j;
		for (int i = 1; i < added2.length; i++)
		{
			j=i-1;
			temp=added2[i];
			while(j>=0 && added2[j].C_Mid.compareTo(temp.C_Mid)>0)
			{
				added2[j+1]=added2[j];
				j=j-1;
			}added2[j+1]=temp;
		}
		return added2;
	}
	private static CampusMind[] bsort(CampusMind[] insertionsorted2) {
		for (int i = 0; i < insertionsorted2.length-1; i++) 
		{
			for (int j = 0; j < insertionsorted2.length-i-1; j++)
			{
				if(insertionsorted2[j].Name.compareTo(insertionsorted2[j+1].Name)>0)
				{
					CampusMind temp = insertionsorted2[j];
					insertionsorted2[j] = insertionsorted2[j+1];
					insertionsorted2[j+1] = temp;
				}
				
			}
		}
		return insertionsorted2;
	}
	private static void display(CampusMind[] d)
	{
		for (int i = 0; i < d.length; i++)
		{
			System.out.println("mid is : "+d[i].C_Mid);
			System.out.println("name is: "+d[i].Name);
			System.out.println("capability moved: "+d[i].cap_moved);
			System.out.println();
		}
	}

}
