package com.mindtree.campusmind;

public class CampusMind 
{
	String C_Mid;
	String Name;
	int cap_moved;
	public CampusMind() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CampusMind(String c_Mind, String name, int cap_moved) {
		super();
		C_Mid = c_Mind;
		Name = name;
		this.cap_moved = cap_moved;
	}
	
}
